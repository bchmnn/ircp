
/*****************************************************************************************/
/* Frames transmitted over the socket:                                                   */
/*                                                                                       */
/* +---------------+------------------+-----------------+---+-----------------+          */
/* | FrameType | Parameter 1 | Parameter 2 | ... | paramater N |                         */
/*                                                                                       */
/* FrameType (16Bits):                                                                   */
const REGISTER_WRITE = 1; /* Command:                                                    */
						  /* Parameter 1: register address  (16 Bits),                   */
                          /* Parameter 2: register value    (16 Bits)                    */
const REGISTER_READ  = 2; /* Command:                                                    */
						  /* Parameter 1: register address  (16 Bits)                    */
						  /* Response:                                                   */
						  /* Parameter 1: register value    (16 Bits)                    */
const SPI_INIT       = 3; /* Command:                                                    */
const CC1200_CMD     = 4; /* Command:                                                    */
                          /* Parameter 1: command strobe    (16 Bits)                    */
const CC1200_STATE   = 5; /* Command:                                                    */
                          /* Response:                                                   */
						  /* Parameter 1: state information (16 Bits)                    */
const SET_MODE = 6;       /* Command:													 */
						  /* Parameter 1: mode (16 Bits)                                 */
const RSSI_GET = 7;       /* Command:                                                    */
const START_RX = 8;       /* Command:                                                    */
						  /* Parameter 1: Sequencenumer on/off (16 Bits)                 */
const STOP_RX  = 9;       /* Command:                                                    */
const FIFO_DATA= 10;      /* Command:                                                    */
const START_TX = 11;      /* Command:                                                    */
						  /* Parameter 1: Sequencenumer on/off (16 Bits)                 */
const STOP_TX  = 12;      /* Command:                                                    */

/*****************************************************************************************/

/****************************************************************************************/
/* name: 		InitSPI                                                                 */
/* Purpose: 	Instructs BeagleBone Black to initialize SPI interface                  */
/* Parameter: 	-                                                                       */
/* Result:		-   																	*/
/*                                                                                      */
/* Remark:		ReadReg allocates an ArrayBuffer and fills the buffer with the          */
/*				appropriate values and sends the buffer BeagleBone Black                */
/****************************************************************************************/
function InitSPI () {

	var spi_buf = new ArrayBuffer(2);
	var cmd = new Uint16Array(spi_buf, 0, 1);
	
	cmd[0] = SPI_INIT;

	if (Debug) console.log ("Initializing SPI");
	
	socket.emit('SpiInit', spi_buf);  

}

function StartRx () {

	var start_rx_buf = new ArrayBuffer(8);
	var cmd        = new Uint16Array(start_rx_buf, 0, 1);
	var seq        = new Uint16Array(start_rx_buf, 2, 1);
	var pkt_format = new Uint16Array(start_rx_buf, 4, 1);
	var pkt_len    = new Uint16Array(start_rx_buf, 6, 1);
	
	cmd[0] = START_RX;
	seq[0] = seq_on;
	if (Debug) console.log ("Start RX");
	
	socket.emit('StartRx', start_rx_buf); 
	
	Max_Pkt_Cnt = $("#Packet_Count").val();
	Pkt_Cnt = 0;
	
	if ($('#infinite').is(':checked')) Max_Pkt_Cnt=0;
 
    var conceptName = $('#Length_Config').find(":selected").text();

    if (conceptName.localeCompare("Fixed")==0) {
        pkt_len[0]=$("#Frame_Length").val();
		pkt_format[0]=0;
    }
    if (conceptName.localeCompare("Variable")==0) {
		pkt_format[0]=1;
    }
}

function StartTx () {

	var tx_len = ($("#TX_Frame_Length").val());
	var tx_seq = ($('#TX_Add_Seq').is(':checked'));
	var tx_inf = ($('#TX_infinite').is(':checked'));
	
	if (tx_seq) tx_len-=2;
	console.log("len:" + tx_len);
	
	var b_size = parseInt(tx_len)+10;
	
	var start_tx_buf = new ArrayBuffer(b_size);
	var cmd        = new Uint16Array(start_tx_buf, 0, 1);
	var count      = new Uint16Array(start_tx_buf, 2, 1);
	var seq        = new Uint16Array(start_tx_buf, 4, 1);
	var pkt_format = new Uint16Array(start_tx_buf, 6, 1);
	var pkt_len    = new Uint16Array(start_tx_buf, 8, 1);
	var pkt        = new Uint8Array(start_tx_buf, 10, tx_len);

	cmd[0] = START_TX;
	seq[0] = ($('#TX_Add_Seq').is(':checked'));
	pkt_len[0]=tx_len;
	
	if (tx_inf)
		count[0]= 0;
	else
		count[0]= $("#TX_Packet_Count").val();
	
    var conceptName = $('#TX_Length_Config').find(":selected").text();
    if (conceptName.localeCompare("Fixed")==0) {
        //pkt_len[0]=$("#Frame_Length").val();
		pkt_format[0]=0;
    }
    if (conceptName.localeCompare("Variable")==0) {
		pkt_format[0]=1;
    }

	
	var pkt_cnt = 0;
	for (pkt_cnt=0; pkt_cnt<tx_len; pkt_cnt++) {pkt[pkt_cnt]=tx_frame[pkt_cnt].charCodeAt(0); console.log(pkt[pkt_cnt]);}
	
	console.log("Count:" + count[0] + " format:" + pkt_format[0] + " len:" + pkt_len[0] + " seq:" + seq[0] + " tx_frame:" + pkt + " bufferlen:" + pkt.length);
	
	socket.emit('StartTx', start_tx_buf); 


}

function StopRx () {

	var stop_rx_buf = new ArrayBuffer(2);
	var cmd = new Uint16Array(stop_rx_buf, 0, 1);
	
	cmd[0] = STOP_RX;

	if (Debug) console.log ("Stop RX");
	
	socket.emit('StopRx', stop_rx_buf);  

}

function StopTx () {

	var stop_tx_buf = new ArrayBuffer(2);
	var cmd = new Uint16Array(stop_tx_buf, 0, 1);
	
	cmd[0] = STOP_TX;

	if (Debug) console.log ("Stop TX");
	
	socket.emit('StopTx', stop_tx_buf);  

}

function RSSIGet () {
	var buffer = new ArrayBuffer(4);
	var cmd = new Uint16Array(buffer, 0, 1);	
	var rssi_value = new Uint16Array(buffer, 2, 1);

	if (Debug) console.log ("Get RSSI Value");
	
	cmd[0] = RSSI_GET;
	rssi_value[0] = 0;
	socket.emit ('RSSI_GET', buffer);

}

function SetMode (cc1200_mode) {
	var buffer = new ArrayBuffer(4);
	var cmd = new Uint16Array(buffer, 0, 1);
	var mode = new Uint16Array(buffer, 2, 1);
	
	if (Debug) console.log ("Funktion Set Mode");
	
	cmd[0] = SET_MODE;
	mode[0] = cc1200_mode;
	socket.emit ('SET_MODE', buffer);

}

function SetRssiOfset (offset) {

	WriteReg (AGC_GAIN_ADJUST, offset);
	ReadReg (AGC_GAIN_ADJUST)
}

function GetRssiOffset () {
	var rssi_off = $("#AGC_GAIN_ADJUST").val();
	$("#RSSI_off").html(rssi_off);
}

function CC1200RetrieveState () {

	var state_buf = new ArrayBuffer(4);
	var cmd       = new Uint16Array(state_buf, 0, 1);
	
	if (Debug) console.log ("Retrieving state");
	
	cmd[0]     = CC1200_STATE;
	socket.emit ('CC1200State', state_buf);
	
	
}

/****************************************************************************************/
/* Strobe commands                                                                      */
const S_RES		= 0x30; 
const S_FSTXON	= 0x31; 
const S_XOFF	= 0x32; 
const S_CAL		= 0x33; 
const S_RX		= 0x34; 
const S_TX		= 0x35; 
const S_IDLE	= 0x36; 
const S_AFC		= 0x37; 
const S_WOR		= 0x38; 
const S_PWD		= 0x39; 
const S_FRX		= 0x3A; 
const S_FTX		= 0x3B; 
const S_WORRST	= 0x3C; 
const S_NOP		= 0x3D; 

/****************************************************************************************/
/* name: 		Execute Command Strobe (CC1200_COMMAND)                                 */
/* Purpose: 	Instructs BeagleBone Black to execute a command strobe on CC1200.       */
/* Parameter: 	command strobe                                                          */
/* Result:		-   																	*/
/*                                                                                      */
/* Remark:		CC1200_COMMAND allocates an ArrayBuffer and fills the buffer with the   */
/*				appropriate values and sends the buffer BeagleBone Black                */
/****************************************************************************************/
function CC1200_COMMAND (strobe) {

	var cmd_buf = new ArrayBuffer(4);
	var cmd     = new Uint16Array(cmd_buf, 0, 1);
	var command = new Uint16Array(cmd_buf, 2, 1);
	
	cmd[0]     = CC1200_CMD;
	command[0] = strobe;
	
	if (Debug) console.log ("Executing command strobe:" + command[0]);
	
	if (strobe>=0x30 && strobe<=0x3D) {
		socket.emit ('CC1200Command', cmd_buf);
		CC1200RetrieveState ()
	} else
		alert ("ERROR: command strobe out of range");
}


/****************************************************************************************/
/* name: 		ReadReg                                                                 */
/* Purpose: 	Instructs BeagleBone Black to read register value from CC1200           */
/*				Register value will be received from socket later. ReadReg only         */
/*				instructs to read the register value. Instruction is done by the        */                                    
/*				command REGISTER_READ                                                   */
/* Parameter: 	Address of the register                                                 */
/* Result:		-   																	*/
/*                                                                                      */
/* Remark:		ReadReg allocates an ArrayBuffer and fills the buffer with the          */
/*				appropriate values and sends the buffer BeagleBone Black                */
/****************************************************************************************/
function ReadReg (address) {

	var reg_buf = new ArrayBuffer(6);
	var cmd = new Uint16Array(reg_buf, 0, 1);
	var adr = new Uint16Array(reg_buf, 2, 1);
	var val = new Uint16Array(reg_buf, 4, 1);

	cmd[0] = REGISTER_READ;
	adr[0] = address;
	val[0] = 0xFF;

	if (Debug) console.log ("Reading Register at adr:" + adr[0].toString(16));
	
	socket.emit('RegRead', reg_buf);  
}

/****************************************************************************************/
/* name: 		WriteReg                                                                */
/* Purpose: 	Instructs BeagleBone Black to write register value to CC1200.           */  
/*              Instruction is done by the command REGISTER_WRITE. To verify that the   */
/*              Register has been written, the function ReadReg will be called after    */
/*              writing                                                                 */
/* Parameter: 	address: Address of the register,                                       */
/*				value:   Desired value of the register.                                 */
/* Result:		-   																	*/
/*                                                                                      */
/* Remark:		WriteReg allocates an ArrayBuffer and fills the buffer with the         */
/*				appropriate values and sends the buffer BeagleBone Black.               */
/****************************************************************************************/
function WriteReg (address, value) {

	var reg_buf = new ArrayBuffer(6);
	var cmd = new Uint16Array(reg_buf, 0, 1);
	var adr = new Uint16Array(reg_buf, 2, 1);
	var val = new Uint16Array(reg_buf, 4, 1);

	cmd[0] = REGISTER_WRITE;
	adr[0] = address;
	val[0] = value;

	if (Debug) console.log ("Reading Register at adr:" + adr[0].toString(16));
	
	socket.emit('RegWrite', reg_buf);
	
	var fileDesciption = document.getElementById('description_area');
	fileDesciption.innerText = fileDesciption.innerText + "*";
	ReadReg (address);
}

/****************************************************************************************/
/* name: 		ReadAllRegVals (Read all register values)                               */
/* Purpose: 	Instructs BeagleBone Black to read all register value from CC1200       */
/*				by using the function ReadReg                                           */
/* Parameter: 	-                                                                       */
/* Result:		-    																	*/
/*                                                                                      */
/* Remark:		-                                                                       */
/****************************************************************************************/
function ReadAllRegVals () {

	var i = 0;
	
	for (i=0; i < 0x2F; i++) ReadReg(i);
	for (i=0x2F00; i< 0x2F3A; i++) ReadReg(i);
	for (i=0x2F64; i< 0x2FA3; i++) ReadReg(i);
	for (i=0x2FD2; i< 0x2FDB; i++) ReadReg(i);

}
 
/****************************************************************************************/
/* name: 		Reading Register                                                        */
/* Purpose: 	Receives register values from socket to BeagleBone Black                */
/*				Register values are stored in the html register window.                 */
/* Parameter: 	-                                                                       */
/* Result:		-    																	*/
/*                                                                                      */
/* Remark:		-                                                                       */
/****************************************************************************************/
socket.on('RegRead', function(buf){
		
	var cmd = new Uint16Array(buf, 0, 1);
	var adr = new Uint16Array(buf, 2, 1);
	var val = new Uint16Array(buf, 4, 1);

	if (Debug) {		
		console.log ('Register: ' + RegName(adr[0]));			
		console.log ('Register value: ' + val[0].toString(16));
		console.log ('Buffer length: ' + buf.byteLength);
	}

	var reg = document.getElementById(RegName(adr[0]));
	if (val < 16) reg.value = "0" + val[0].toString(16);
	else reg.value = val[0].toString(16);
	
	if (RegToRead == adr[0]) {
		var menue_reg = document.getElementById('read_reg_value');
		if (val < 16) menue_reg.value = "0" + val[0].toString(16);
		else menue_reg.value = val[0].toString(16);
	}
});

socket.on ('CC1200State', function(buf){

	var cmd = new Uint16Array(buf, 0, 1);
	var val = new Uint16Array(buf, 2, 1);
	
	var cc1200_state = document.getElementById('cc1200_status');

	CC1200State = val[0];
	cc1200_state.innerHTML = print_status ();
	
	//UpdateCC1200State ();
	if (Debug) {
		console.log ("State is " + CC1200State);
	}
	
});

socket.on ('RSSI_GET', function(buf){

	var cmd = new Uint16Array(buf, 0, 1);
	var val = new Uint16Array(buf, 2, 1);
	
	console.log ("RSSI is: " + val[0]);
	AddRSSI (RSSI_time, val[0]);
	RSSI_time = RSSI_time + 1.0;
	chart.update();
});


socket.on ('FIFO_DATA', function(buf){

	var fifo_data_cmd    = new Uint16Array(buf, 0, 1);
	var fifo_data_length = new Uint16Array(buf, 2, 1);
	var fifo_data_seq    = new Uint16Array(buf, 4, 1);
	var fifo_data_rssi    = new Uint16Array(buf, 6, 1);
	var fifo_data_crc    = new Uint16Array(buf, 8, 1);
	var fifo_data_data   = new Uint8Array(buf, 10, fifo_data_length[0]);

	var objDiv = document.getElementById("RX_Packet_Output");
	objDiv.scrollTop = objDiv.scrollHeight;

	$("#RX_Packet_Output").append("length:");
	$("#RX_Packet_Output").append(fifo_data_length[0]);
	
	if(seq_on){
		$("#RX_Packet_Output").append(" seq:");
		$("#RX_Packet_Output").append(fifo_data_seq[0]);
	}

	$("#RX_Packet_Output").append(" crc:");
	if (fifo_data_crc[0]) 
		$("#RX_Packet_Output").append("ok");
	else
		$("#RX_Packet_Output").append("error");

	$("#RX_Packet_Output").append(" rssi:");
	$("#RX_Packet_Output").append(fifo_data_rssi[0]);
	
	var enc = new TextDecoder();
	$("#RX_Packet_Output").append(" data:");
	$("#RX_Packet_Output").append(enc.decode(fifo_data_data));
	
	$("#RX_Packet_Output").append("<br>");

	if (Max_Pkt_Cnt>0) {
		if (Pkt_Cnt<Max_Pkt_Cnt) {
			Pkt_Cnt++;
		} else {
	        Start_Rx = false;
	        StopRx();
	        $("#FIFO_RX_button").html('Start');
	        Enable_HF_Params ();

			Pkt_Cnt = 0;
		}
	}
});

socket.on ('STOP_TX', function(buf){

	var cmd = new Uint16Array(buf, 0, 1);
	Packet_Tx()
	
});


    	
