/****************************************************************************************/
/* name: 		myTKN   								                                */
/* Purpose: 	Shows the TKN menue                                                     */
/* Parameter: 	-                                                                       */
/* Result:		-    																	*/
/*                                                                                      */
/* Remark:		-                                                                       */
/****************************************************************************************/
function myTKN() {document.getElementById("About").classList.toggle("show");}

/****************************************************************************************/
/* name: 		myFile 							 		                                */
/* Purpose: 	Shows the File menue					                                */
/* Parameter: 	-                                                                       */
/* Result:		-    																	*/
/*                                                                                      */
/* Remark:		-                                                                       */
/****************************************************************************************/
function myFile() {document.getElementById("File").classList.toggle("show");}

/****************************************************************************************/
/* name: 		myRegister 							 		                            */
/* Purpose: 	Shows the Register menue					                            */
/* Parameter: 	-                                                                       */
/* Result:		-    																	*/
/*                                                                                      */
/* Remark:		-                                                                       */
/****************************************************************************************/
function myRegister() {document.getElementById("Register").classList.toggle("show");}

function myCC1200mode() {document.getElementById("Mode").classList.toggle("show");}

/****************************************************************************************/
/* name: 		Close the dropdown menue if the user clicks outside of it 				*/
/* Purpose: 												                            */
/* Parameter: 	event: mouse click                                                      */
/* Result:		-    																	*/
/*                                                                                      */
/* Remark:		-                                                                       */
/****************************************************************************************/
window.onclick = function(event) {

	/* get the menue name */
 	var dropdown = event.target.innerHTML;
	if (Debug) console.log ("inner event: " + dropdown);

	/* user has clicked outside the TKN dropdown menue */
    if (dropdown!='TKN') {
    	/* close the TKN dropdown menue */
    	var dropdowns = document.getElementsByClassName("menue-about-content");
    	for (var i = 0; i < dropdowns.length; i++) {
      		if (dropdowns[i].classList.contains('show')) { 		
      			dropdowns[i].classList.remove('show');
      		}
    	}
  	}

	/* user has clicked outside the File dropdown menue */
	if (dropdown!='File') {
    	/* close the File dropdown menue */
    	var dropdowns = document.getElementsByClassName("menue-file-content");
    	for (var i = 0; i < dropdowns.length; i++) {
      		if (dropdowns[i].classList.contains('show')) {
        		dropdowns[i].classList.remove('show');
      		}
    	}
  	}
  	
	/* user has clicked outside the Register dropdown menue */
	if (dropdown!='CC1200') {
    	/* close the Register dropdown menue */
    	var dropdowns = document.getElementsByClassName("dropdown-content2");
    	for (var i = 0; i < dropdowns.length; i++) {
      		if (dropdowns[i].classList.contains('show')) {
        		dropdowns[i].classList.remove('show');
      		}
    	}
	}
	
	if (dropdown!='Mode') {
    	/* close the Register dropdown menue */
    	var dropdowns = document.getElementsByClassName("dropdown-content3");
    	for (var i = 0; i < dropdowns.length; i++) {
      		if (dropdowns[i].classList.contains('show')) {
        		dropdowns[i].classList.remove('show');
      		}
    	}
	}

}

/****************************************************************************************/
/* name: 		ShowAboutWindow (Shown about window)   								    */
/* Purpose: 	Function ShowAboutWindow will be called, if the About menue item of     */
/*              the TKN menue has been clicked and the About window will be displayed.  */
/* Parameter: 	-                                                                       */
/* Result:		-    																	*/
/*                                                                                      */
/* Remark:		-                                                                       */
/****************************************************************************************/
function ShowAboutWindow() {
	/* this will display the About window */
	about_item = document.getElementById('about_item');
    about_item.className = 'about_item_window';
      
    /* install an event handler to close the window by pressing the close button of
        the about window */
    CloseBtn = document.getElementById('close_about');
    CloseBtn.addEventListener('click',CloseAboutWindow);
}

/****************************************************************************************/
/* name: 		CloseAboutWindow (Close about window)   								*/
/* Purpose: 	Function CloseAboutWindow will be called, if the close button of the    */
/*              about window will be clicked. The about window will then be hidden.	    */
/* Parameter: 	-                                                                       */
/* Result:		-    																	*/
/*                                                                                      */
/* Remark:		-                                                                       */
/****************************************************************************************/
function CloseAboutWindow(){
	/* close the window */
	about_item.className = 'about_item_hidden';
}

/****************************************************************************************/
/* name: 		CancelInitWindow (Close SPI init window)   								*/
/* Purpose: 	Function CancelInitWindow will be called, if the cancel button of the   */
/*              SPI init window will be clicked. The window will then be hidden.	    */
/* Parameter: 	-                                                                       */
/* Result:		-    																	*/
/*                                                                                      */
/* Remark:		-                                                                       */
/****************************************************************************************/
function CancelInitWindow () {
	init_spi_item.className = 'init_item_hidden';
}

/****************************************************************************************/
/* name: 		OkInitWindow (OK SPI init window)   				     				*/
/* Purpose: 	Function OkInitWindow will be called, if the Ok button of the           */
/*              SPI init window will be clicked. The window will then be hidden and the */
/*              SPI interface of the Beaglebone Black initialized               	    */
/* Parameter: 	-                                                                       */
/* Result:		-    																	*/
/*                                                                                      */
/* Remark:		This will only reset the SPI interface, but not the registers           */
/****************************************************************************************/
function OkInitWindow () {
	InitSPI ();
	CancelInitWindow ();
}

/****************************************************************************************/
/* name: 		ShowInitSPIWindow (Shown Init SPI window)   		    			    */
/* Purpose: 	Function ShowInitSPIWindow will be called, if the Init SPI menue item of*/
/*              the Register menue has been clicked and the Init SPI dialog will be     */
/*              displayed.                                                              */
/* Parameter: 	-                                                                       */
/* Result:		-    																	*/
/*                                                                                      */
/* Remark:		-                                                                       */
/****************************************************************************************/
function ShowInitSPIWindow() {
	/* this will display the Init SPI window */
	init_spi_item = document.getElementById('init_item');
    init_spi_item.className = 'init_item_window';
      
    /* install an event handler to close the window by pressing the can cel button of
        the Init SPI window */
    CancelInitBtn = document.getElementById('cancel_init');
    CancelInitBtn.addEventListener('click', CancelInitWindow);
    
    /* install an event handler to close the window by pressing the can cel button of
        the Init SPI window */
    OkInitBtn = document.getElementById('ok_init');
    OkInitBtn.addEventListener('click', OkInitWindow);

}

function CancelReadRegWindow ( ) {

	read_reg_item.className = 'read_item_hidden';
}

	

function OkReadRegWindow () {

	var reg_adr_ = document.getElementById('read_reg_adr');

	RegToRead = parseInt(reg_adr_.value, 16);
	ReadReg(parseInt(reg_adr_.value, 16));
}

const SynSerialRx=1;
const SynSerialTx=2;
const FifoRx     =3;
const FifoTx     =4;


function ShowRXSynchronousSerialMode() {

    RSSI_ON = false;
    SetMode(SynSerialRx);
    console.log ("ShowRXSynchronousSerialMode"); 
    ReadAllRegVals();
    $("#rssi_button").html('RSSI on');
    SetRssiOfset (48); // Trial and Error
    GetRssiOffset ();

    frame_item = document.getElementById('TX_Synchronous_Serial_Mode');
    frame_item.className = 'frame_hidden';
	frame_item = document.getElementById('RX_Synchronous_Serial_Mode');
    frame_item.className = 'frame_show';
    frame_item = document.getElementById('RX_Packet_Mode');
    frame_item.className = 'frame_hidden';    
    $("#TX_Packet_Mode").attr('class', 'frame_hidden');
}

function ShowTXSynchronousSerialMode() {

    RSSI_ON = false;

    SetMode(SynSerialTx);
    ReadAllRegVals();
    
    $("#rssi_button").html('RSSI on');

    frame_item = document.getElementById('RX_Synchronous_Serial_Mode');
    frame_item.className = 'frame_hidden';    
	frame_item = document.getElementById('TX_Synchronous_Serial_Mode');
    frame_item.className = 'frame_show';
    frame_item = document.getElementById('RX_Packet_Mode');
    frame_item.className = 'frame_hidden';
    $("#TX_Packet_Mode").attr('class', 'frame_hidden');
}

function ShowRxPacketMode() {

    RSSI_ON = false;

    SetMode(FifoRx);
    SetPacketMode ();
    Length_Config();
    ReadAllRegVals();

	$("#RX_Packet_Output").html("");
	    
    $("#FIFO_RX_button").html('Start');

    $("#RX_Synchronous_Serial_Mode").attr('class', 'frame_hidden');
    $("#TX_Synchronous_Serial_Mode").attr('class', 'frame_hidden');
    $("#RX_Packet_Mode").attr('class', 'frame_show');
    $("#TX_Packet_Mode").attr('class', 'frame_hidden');
    $("#Packet_Count").val(10);
    $("#Length_Config").val("Fixed");
}

function ShowTxPacketMode() {

    RSSI_ON = false;

    SetMode(FifoTx);
    SetTxPacketMode ();
    TX_Length_Config();

    ReadAllRegVals();

	$("#RX_Packet_Output").html("");
	    
    $("#TX_Packet_Input").html('');
    $("#TX_Frame_Length").val(0);

    $("#RX_Synchronous_Serial_Mode").attr('class', 'frame_hidden');
    $("#TX_Synchronous_Serial_Mode").attr('class', 'frame_hidden');
    $("#RX_Packet_Mode").attr('class', 'frame_hidden');
    $("#TX_Packet_Mode").attr('class', 'frame_show');
    $("#TX_Packet_Count").val(10);
    $("#TX_Length_Config").val("Fixed");
}

function ShowReadRegWindow() {
	/* this will display the Init SPI window */
	read_reg_item = document.getElementById('read_reg_item');
    read_reg_item.className = 'read_reg_item_window';
      
    /* install an event handler to close the window by pressing the can cel button of
        the Init SPI window */
    CancelReadRegBtn = document.getElementById('cancel_read_reg');
    CancelReadRegBtn.addEventListener('click', CancelReadRegWindow);
    
    /* install an event handler to close the window by pressing the can cel button of
        the Init SPI window */
    OkReadRegBtn = document.getElementById('ok_read_reg');
    OkReadRegBtn.addEventListener('click', OkReadRegWindow);

}

function CancelWriteRegWindow ( ) {

	write_reg_item.className = 'write_item_hidden';
}

function OkWriteRegWindow () {

	var reg_adr = document.getElementById('write_reg_adr');
	var reg_val = document.getElementById('write_reg_value');

	WriteReg (parseInt(reg_adr.value, 16), parseInt(reg_val.value, 16));
	ReadReg(parseInt(reg_adr.value, 16));
	CancelWriteRegWindow();
}

function ShowWriteRegWindow() {
	/* this will display the Init SPI window */
	write_reg_item = document.getElementById('write_reg_item');
    write_reg_item.className = 'write_reg_item_window';
      
    /* install an event handler to close the window by pressing the can cel button of
        the Init SPI window */
    CancelWriteRegBtn = document.getElementById('cancel_write_reg');
    CancelWriteRegBtn.addEventListener('click', CancelWriteRegWindow);
    
    /* install an event handler to close the window by pressing the can cel button of
        the Init SPI window */
    OkWriteRegBtn = document.getElementById('ok_write_reg');
    OkWriteRegBtn.addEventListener('click', OkWriteRegWindow);

}

function GetWriteRegValues() {

	var reg_adr = document.getElementById('write_reg_adr');
	var name = RegName (parseInt(reg_adr.value, 16));
	var reg_val = document.getElementById(name);
	var cur_val = document.getElementById('old_reg_value');
	
	cur_val.innerText = "0x" + reg_val.value + ")";	
}

/****************************************************************************************/
/* name: 		ShowLoadWindow (Shown Load window)   								    */
/* Purpose: 	Function ShowLoadWindow will be called, if the Load menue item of       */
/*              the File menue has been clicked and the Load dialog will be displayed.  */
/* Parameter: 	-                                                                       */
/* Result:		-    																	*/
/*                                                                                      */
/* Remark:		-                                                                       */
/****************************************************************************************/
function ShowExportWindow() {
	/* this will display the Load dialog */
	export_item = document.getElementById('export_item');
	export_item.className = 'export_item_window';

    /* install an event handler to close the dialog by pressing the close button of
        the Load dialog */
	CloseExportBtn = document.getElementById('close_export');
	CloseExportBtn.addEventListener('click',CloseExportWindow);
	
	CancelExportBtn = document.getElementById('cancel_export');
	CancelExportBtn.addEventListener('click',CancelExportWindow);
		
}


/****************************************************************************************/
/* name: 		Parse Register Configuration File (parse)      						    */
/* Purpose: 	Parses a register configuration file.	                                */
/*              A register configuration file starts with the keyword "Description"     */
/*              followed with a short description. The description must be contained in */
/*              the first line.                                                         */
/*              After the description in each row the name of the register and its      */
/*				desired vale will be stored. Between the register name and the value    */
/*              there must be a single space. The value of each register must be in     */
/*              a two digit hex representation.                                         */
/* Parameter: 	ev the event.                                                           */
/* Result:		-    																	*/
/*                                                                                      */
/* Remark:		This function will be called be the eventhandler. The listener will be  */
/*              installed by function Parse_Reg_File                                    */
/****************************************************************************************/	
function parse (ev) {

	/* determine the file instance */
	var file = fileInput.files[0];
	
	/* create a file reader */
	var reader = new FileReader();

				
	reader.onload = function (ev) {
	/************************************************************************************/
	/* Purpose: 	load the register configuration file and parse it contents.	        */
	/* Parameter: 	ev the event.                                                       */
	/* Result:		-    																*/
	/*                                                                                  */
	/* Remark:		                                                                    */
	/************************************************************************************/

		/* register configuration file content */
		var content;
		
		/* the location, where the description will be stored in the screen */
		var fileDesciption = document.getElementById('description_area');

		function ParseAndWrite (reg) {
		/*********************************************************************************/
		/* Purpose: 	search a register name and write the value to the CC1200	     */
		/* Parameter: 	reg	register n´name                                              */
		/* Result:		-    															 */
		/*                                                                               */
		/* Remark:		                                                                 */
		/*********************************************************************************/
			var i = content.indexOf(reg);	

			if (i>=0) {
				var val = content.slice(i+reg.length+1, i+reg.length+3);
				WriteReg (RegAddr(reg), parseInt(val, 16));
			}
		}

		/* read the content of the file */
		content = reader.result;
	
		/* write the following registers to the CC1200 */
		ParseAndWrite ('IOCFG3'				);
		ParseAndWrite ('IOCFG2'				);
		ParseAndWrite ('IOCFG1'				);
		ParseAndWrite ('IOCFG0'				);
		ParseAndWrite ('SYNC3'				);
		ParseAndWrite ('SYNC2'				);
		ParseAndWrite ('SYNC1'				);
		ParseAndWrite ('SYNC0'				);
		ParseAndWrite ('SYNC_CFG1'			);
		ParseAndWrite ('SYNC_CFG0'			);
		ParseAndWrite ('DEVIATION_M'		);
		ParseAndWrite ('MODCFG_DEV_E'		);
		ParseAndWrite ('DCFILT_CFG'			);
		ParseAndWrite ('PREAMBLE_CFG1'		);
		ParseAndWrite ('PREAMBLE_CFG0'		);
		ParseAndWrite ('IQIC'				);
		ParseAndWrite ('CHAN_BW'			);
		ParseAndWrite ('MDMCFG1'			);
		ParseAndWrite ('MDMCFG0'			);
		ParseAndWrite ('SYMBOL_RATE2'		);
		ParseAndWrite ('SYMBOL_RATE1'		);
		ParseAndWrite ('SYMBOL_RATE0'		);
		ParseAndWrite ('AGC_REF'			);
		ParseAndWrite ('AGC_CS_THR'			);
		ParseAndWrite ('AGC_GAIN_ADJUST'	);
		ParseAndWrite ('AGC_CFG3'			);
		ParseAndWrite ('AGC_CFG2'			);
		ParseAndWrite ('AGC_CFG1'			);
		ParseAndWrite ('AGC_CFG0'			);
		ParseAndWrite ('FIFO_CFG'			);
		ParseAndWrite ('DEV_ADDR'			);
		ParseAndWrite ('SETTLING_CFG'		);
		ParseAndWrite ('FS_CFG'				);
		ParseAndWrite ('WOR_CFG1'			);
		ParseAndWrite ('WOR_CFG0'			);
		ParseAndWrite ('WOR_EVENT0_MSB'		);
		ParseAndWrite ('WOR_EVENT0_LSB'		);
		ParseAndWrite ('RXDCM_TIME'			);
		ParseAndWrite ('PKT_CFG2'			);
		ParseAndWrite ('PKT_CFG1'			);
		ParseAndWrite ('PKT_CFG0'			);
		ParseAndWrite ('RFEND_CFG1'			);
		ParseAndWrite ('RFEND_CFG0'			);
		ParseAndWrite ('PA_CFG1'			);
		ParseAndWrite ('PA_CFG0'			);
		ParseAndWrite ('ASK_CFG'			);
		ParseAndWrite ('PKT_LEN'			);
		ParseAndWrite ('IF_MIX_CFG'			);
		ParseAndWrite ('FREQOFF_CFG'		);
		ParseAndWrite ('TOC_CFG'			);
		ParseAndWrite ('MARC_SPARE'			);
		ParseAndWrite ('ECG_CFG'			);
		ParseAndWrite ('MDMCFG2'			);
		ParseAndWrite ('EXT_CTRL'			);
		ParseAndWrite ('RCCAL_FINE'			);
		ParseAndWrite ('RCCAL_COARSE'		);
		ParseAndWrite ('RCCAL_OFFSET'		);
		ParseAndWrite ('FREQOFF1'			);
		ParseAndWrite ('FREQOFF0'			);
		ParseAndWrite ('FREQ2'				);
		ParseAndWrite ('FREQ1'				);
		ParseAndWrite ('FREQ0'				);
		ParseAndWrite ('IF_ADC2'			);
		ParseAndWrite ('IF_ADC1'			);
		ParseAndWrite ('IF_ADC0'			);
		ParseAndWrite ('FS_DIG1'			);
		ParseAndWrite ('FS_DIG0'			);
		ParseAndWrite ('FS_CAL3'			);
		ParseAndWrite ('FS_CAL2'			);
		ParseAndWrite ('FS_CAL1'			);
		ParseAndWrite ('FS_CAL0'			);
		ParseAndWrite ('FS_CHP'				);
		ParseAndWrite ('FS_DIVTWO'			);
		ParseAndWrite ('FS_DSM1'			);
		ParseAndWrite ('FS_DSM0'			);
		ParseAndWrite ('FS_DVC1'			);
		ParseAndWrite ('FS_DVC0'			);
		ParseAndWrite ('FS_LBI'				);
		ParseAndWrite ('FS_PFD'				);
		ParseAndWrite ('FS_PRE'				);
		ParseAndWrite ('FS_REG_DIV_CML'		);
		ParseAndWrite ('FS_SPARE'			);
		ParseAndWrite ('FS_VCO4'			);
		ParseAndWrite ('FS_VCO3'			);
		ParseAndWrite ('FS_VCO2'			);
		ParseAndWrite ('FS_VCO1'			);
		ParseAndWrite ('FS_VCO0'			);
		ParseAndWrite ('GBIAS6'				);
		ParseAndWrite ('GBIAS5'				);
		ParseAndWrite ('GBIAS4'				);
		ParseAndWrite ('GBIAS3'				);
		ParseAndWrite ('GBIAS2'				);
		ParseAndWrite ('GBIAS1'				);
		ParseAndWrite ('GBIAS0'				);
		ParseAndWrite ('IFAMP'				);
		ParseAndWrite ('LNA'				);
		ParseAndWrite ('RXMIX'				);
		ParseAndWrite ('XOSC5'				);
		ParseAndWrite ('XOSC4'				);
		ParseAndWrite ('XOSC3'				);
		ParseAndWrite ('XOSC2'				);
		ParseAndWrite ('XOSC1'				);
		ParseAndWrite ('XOSC0'				);
		ParseAndWrite ('ANALOG_SPARE'		);
		ParseAndWrite ('PA_CFG3'			);
		ParseAndWrite ('WOR_TIME1'			);
		ParseAndWrite ('WOR_TIME0'			);
		ParseAndWrite ('WOR_CAPTURE1'		);
		ParseAndWrite ('WOR_CAPTURE0'		);
		ParseAndWrite ('BIST'				);
		ParseAndWrite ('DCFILTOFFSET_I1'	);
		ParseAndWrite ('DCFILTOFFSET_I0'	);
		ParseAndWrite ('DCFILTOFFSET_Q1'	);
		ParseAndWrite ('DCFILTOFFSET_Q0'	);
		ParseAndWrite ('IQIE_I1'			);
		ParseAndWrite ('IQIE_I0'			);
		ParseAndWrite ('IQIE_Q1'			);
		ParseAndWrite ('IQIE_Q0'			);
		ParseAndWrite ('RSSI1'				);
		ParseAndWrite ('RSSI0'				);
		ParseAndWrite ('MARCSTATE'			);
		ParseAndWrite ('LQI_VAL'			);
		ParseAndWrite ('PQT_SYNC_ERR'		);
		ParseAndWrite ('DEM_STATUS'			);
		ParseAndWrite ('FREQOFF_EST1'		);
		ParseAndWrite ('FREQOFF_EST0'		);
		ParseAndWrite ('AGC_GAIN3'			);
		ParseAndWrite ('AGC_GAIN2'			);
		ParseAndWrite ('AGC_GAIN1'			);
		ParseAndWrite ('AGC_GAIN0'			);
		ParseAndWrite ('CFM_RX_DATA_OUT'	);
		ParseAndWrite ('CFM_TX_DATA_IN'		);
		ParseAndWrite ('ASK_SOFT_RX_DATA'	);
		ParseAndWrite ('RNDGEN'				);
		ParseAndWrite ('MAGN2'				);
		ParseAndWrite ('MAGN1'				);
		ParseAndWrite ('MAGN0'				);
		ParseAndWrite ('ANG1'				);
		ParseAndWrite ('ANG0'				);
		ParseAndWrite ('CHFILT_I2'			);
		ParseAndWrite ('CHFILT_I1'			);
		ParseAndWrite ('CHFILT_I0'			);
		ParseAndWrite ('CHFILT_Q2'			);
		ParseAndWrite ('CHFILT_Q1'			);
		ParseAndWrite ('CHFILT_Q0'			);
		ParseAndWrite ('GPIO_STATUS'		);
		ParseAndWrite ('FSCAL_CTRL'			);
		ParseAndWrite ('PHASE_ADJUST'		);
		ParseAndWrite ('PARTNUMBER'			);
		ParseAndWrite ('PARTVERSION'		);
		ParseAndWrite ('SERIAL_STATUS'		);
		ParseAndWrite ('MODEM_STATUS1'		);
		ParseAndWrite ('MODEM_STATUS0'		);
		ParseAndWrite ('MARC_STATUS1'		);
		ParseAndWrite ('MARC_STATUS0'		);
		ParseAndWrite ('PA_IFAMP_TEST'		);
		ParseAndWrite ('FSRF_TEST'			);
		ParseAndWrite ('PRE_TEST'			);
		ParseAndWrite ('PRE_OVR'			);
		ParseAndWrite ('ADC_TEST'			);
		ParseAndWrite ('DVC_TEST'			);
		ParseAndWrite ('ATEST'				);
		ParseAndWrite ('ATEST_LVDS'			);
		ParseAndWrite ('ATEST_MODE'			);
		ParseAndWrite ('XOSC_TEST1'			);
		ParseAndWrite ('XOSC_TEST0'			);
		ParseAndWrite ('AES'				);
		ParseAndWrite ('MDM_TEST'			);
		ParseAndWrite ('RXFIRST'			);
		ParseAndWrite ('TXFIRST'			);
		ParseAndWrite ('RXLAST'				);
		ParseAndWrite ('TXLAST'				);
		ParseAndWrite ('NUM_TXBYTES'		);
		ParseAndWrite ('NUM_RXBYTES'		);
		ParseAndWrite ('FIFO_NUM_TXBYTES'	);
		ParseAndWrite ('FIFO_NUM_RXBYTES'	);
		ParseAndWrite ('RXFIFO_PRE_BUF'		);

		
		Parse_Reg_File();
		
		/* print the register configuration name on the screen */
		fileDesciption.innerText = content.substring (12, content.indexOf ('\n'));

	}
		
	reader.readAsText(file);
}

/****************************************************************************************/
/* name: 		Parse Register Configuration File (Parse_Reg_File) 						*/
/* Purpose: 	Installs a event handler to parse a register configuration file.        */
/* Parameter: 	-                                                                       */
/* Result:		-    																	*/
/*                                                                                      */
/* Remark:		-                                                                       */
/****************************************************************************************/	
function Parse_Reg_File() {

	/* get the id of the file selection box */
	fileInput = document.getElementById('load_reg_file');
	var textType = /text.ticc/;
	
	/* set the correct type */
	/* This is important, if two times the same file will be selected */
	/* If the type will be not changed, the second file selection will fail */
	fileInput.type='';
	fileInput.type='file';
	
	/* install an event listener */
	fileInput.addEventListener('change', parse );
}

/****************************************************************************************/
/* name: 		Include a main routine (MainOn)       		  						    */
/* Purpose: 	If the user clicks the checkbox "create main routine", this function    */
/*              checks, if the checkbox was checked or not                      	    */
/* Parameter: 	-                                                                       */
/* Result:		-    																	*/
/*                                                                                      */
/* Remark:		-                                                                       */
/****************************************************************************************/
function MainOn () {
	if (document.export_form.main.checked==true)
		IncludeMain = true;
	else 
		IncludeMain = false;
}

/****************************************************************************************/
/* name: 		CloseExportWindow (Close Export window)   	  						    */
/* Purpose: 	Function CloseExportWindow will be called, if the close button of the   */
/*              Export dialog will be clicked. The Export dialog will then be hidden.   */
/* Parameter: 	-                                                                       */
/* Result:		-    																	*/
/*                                                                                      */
/* Remark:		-                                                                       */
/****************************************************************************************/
function CloseExportWindow(){
	/* close the dialog */
	export_item.className = 'export_item_hidden';
	Export_C(document.getElementById('export_filename').value, IncludeMain);
}

/****************************************************************************************/
/* name: 		CancelExportWindow (Cancel Export window)   	  					    */
/* Purpose: 	Function CancelExportWindow will be called, if the cancel button of the */
/*              Export dialog will be clicked. The Export dialog will then be hidden.   */
/* Parameter: 	-                                                                       */
/* Result:		-    																	*/
/*                                                                                      */
/* Remark:		-                                                                       */
/****************************************************************************************/
function CancelExportWindow () {
	/* close the dialog */
    export_item.className = 'export_item_hidden';
}


/****************************************************************************************/
/* name: 		ShowSaveWindow (Shown Save window)   								    */
/* Purpose: 	Function ShowSavedWindow will be called, if the Save menue item of       */
/*              the File menue has been clicked and the Save dialog will be displayed.  */
/* Parameter: 	-                                                                       */
/* Result:		-    																	*/
/*                                                                                      */
/* Remark:		-                                                                       */
/****************************************************************************************/
function ShowSaveWindow() {
	/* this will display the Sace dialog */
	save_item = document.getElementById('save_item');
	save_item.className = 'save_item_window';

    /* install an event handler to close the dialog by pressing the close button of
        the Save dialog */
	CloseSaveBtn = document.getElementById('close_save');
	CloseSaveBtn.addEventListener('click',CloseSaveWindow);
	
	CancelSaveBtn = document.getElementById('cancel_save');
	CancelSaveBtn.addEventListener('click',CancelSaveWindow);	
}

/****************************************************************************************/
/* name: 		CloseSaveWindow (Close Save window)   		  						    */
/* Purpose: 	Function CloseSaveWindow will be called, if the cancel button of the    */
/*              Save dialog will be clicked. The Save dialog will then be hidden.	    */
/* Parameter: 	-                                                                       */
/* Result:		-    																	*/
/*                                                                                      */
/* Remark:		-                                                                       */
/****************************************************************************************/
function CancelSaveWindow () {
	/* close the dialog */
    save_item.className = 'save_item_hidden';
}

/****************************************************************************************/
/* name: 		CloseSaveWindow (Close Save window)   		  						    */
/* Purpose: 	Function CloseSaveWindow will be called, if the close button of the     */
/*              Save dialog will be clicked. The current register values will be saved  */
/*              and Save dialog will then be hidden.	                                */
/* Parameter: 	-                                                                       */
/* Result:		-    																	*/
/*                                                                                      */
/* Remark:		-                                                                       */
/****************************************************************************************/
function CloseSaveWindow(){
	/* close the dialog */
    CancelSaveWindow ();
	SaveReg(document.getElementById('save_description').value,
			document.getElementById('save_filename').value + ".ticc");
}
