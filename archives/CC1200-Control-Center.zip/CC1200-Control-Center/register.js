/****************************************************************************************/
/* name: 		UpdateRegValue (Update Register Value)                                  */
/* Purpose: 	If a register value in the register window has been changed (by a       */
/*              a click, changing the register value and then pressing the return key,  */
/*              this function will ve called. UpdateRegValue calls WriteReg to change   */
/*              the register value.                                                     */
/* Parameter: 	register_id: html id of the register                                    */
/* Result:		-    																	*/
/*                                                                                      */
/* Remark:		-                                                                       */
/****************************************************************************************/
function UpdateRegValue (register_id) {
	var register = document.getElementById(register_id);

	if (register.checkValidity()==true) {
		if (Debug) {
			console.log ("registername:" + register.id);
			console.log ("sedezimal:" + register.value);
			console.log ("dezimal:" + parseInt(register.value, 16));
			console.log ("bin�r:" + parseInt(register.value,16).toString(2));
			console.log ("Adr: 0x" + RegAddr(register.id).toString(16));
		}
		
		WriteReg (RegAddr(register.id), parseInt(register.value, 16));
	}
}

/****************************************************************************************/
/* Register addresses:                                                                  */
const IOCFG3			= 0x00; 
const IOCFG2			= 0x01; 
const IOCFG1			= 0x02; 
const IOCFG0			= 0x03; 
const SYNC3				= 0x04; 
const SYNC2				= 0x05; 
const SYNC1				= 0x06; 
const SYNC0				= 0x07; 
const SYNC_CFG1			= 0x08; 
const SYNC_CFG0			= 0x09; 
const DEVIATION_M		= 0x0A; 
const MODCFG_DEV_E		= 0x0B; 
const DCFILT_CFG		= 0x0C; 
const PREAMBLE_CFG1		= 0X0D; 
const PREAMBLE_CFG0		= 0x0E; 
const IQIC				= 0x0F; 
const CHAN_BW			= 0x10; 
const MDMCFG1			= 0x11; 
const MDMCFG0			= 0x12; 
const SYMBOL_RATE2		= 0x13; 
const SYMBOL_RATE1		= 0x14; 
const SYMBOL_RATE0		= 0x15; 
const AGC_REF			= 0x16; 
const AGC_CS_THR		= 0x17; 
const AGC_GAIN_ADJUST	= 0x18; 
const AGC_CFG3			= 0x19; 
const AGC_CFG2			= 0x1A; 
const AGC_CFG1			= 0x1B; 
const AGC_CFG0			= 0x1C; 
const FIFO_CFG			= 0X1D; 
const DEV_ADDR			= 0x1E; 
const SETTLING_CFG		= 0x1F; 
const FS_CFG			= 0x20; 
const WOR_CFG1			= 0x21; 
const WOR_CFG0			= 0x22; 
const WOR_EVENT0_MSB	= 0x23; 
const WOR_EVENT0_LSB	= 0x24; 
const RXDCM_TIME		= 0x25; 
const PKT_CFG2			= 0x26; 
const PKT_CFG1			= 0x27; 
const PKT_CFG0			= 0x28; 
const RFEND_CFG1		= 0x29; 
const RFEND_CFG0		= 0x2A; 
const PA_CFG1			= 0x2B; 
const PA_CFG0			= 0x2C; 
const ASK_CFG			= 0X2D; 
const PKT_LEN			= 0x2E; 

const IF_MIX_CFG		= 0x2F00;
const FREQOFF_CFG		= 0x2F01;
const TOC_CFG			= 0x2F02;
const MARC_SPARE		= 0x2F03;
const ECG_CFG			= 0x2F04;
const MDMCFG2			= 0x2F05;
const EXT_CTRL			= 0x2F06;
const RCCAL_FINE		= 0x2F07;
const RCCAL_COARSE		= 0x2F08;
const RCCAL_OFFSET		= 0x2F09;
const FREQOFF1			= 0x2F0A;
const FREQOFF0			= 0x2F0B;
const FREQ2				= 0x2F0C;
const FREQ1				= 0x2F0D;
const FREQ0				= 0x2F0E;
const IF_ADC2			= 0x2F0F;
const IF_ADC1			= 0x2F10;
const IF_ADC0			= 0x2F11;
const FS_DIG1			= 0x2F12;
const FS_DIG0			= 0x2F13;
const FS_CAL3			= 0x2F14;
const FS_CAL2			= 0x2F15;
const FS_CAL1			= 0x2F16;
const FS_CAL0			= 0x2F17;
const FS_CHP			= 0x2F18;
const FS_DIVTWO			= 0x2F19;
const FS_DSM1			= 0x2F1A;
const FS_DSM0			= 0x2F1B;
const FS_DVC1			= 0x2F1C;
const FS_DVC0			= 0x2F1D;
const FS_LBI			= 0x2F1E;
const FS_PFD			= 0x2F1F;
const FS_PRE			= 0x2F20;
const FS_REG_DIV_CML	= 0x2F21;
const FS_SPARE			= 0x2F22;
const FS_VCO4			= 0x2F23;
const FS_VCO3			= 0x2F24;
const FS_VCO2			= 0x2F25;
const FS_VCO1			= 0x2F26;
const FS_VCO0			= 0x2F27;
const GBIAS6			= 0x2F28;
const GBIAS5			= 0x2F29;
const GBIAS4			= 0x2F2A;
const GBIAS3			= 0x2F2B;
const GBIAS2			= 0x2F2C;
const GBIAS1			= 0x2F2D;
const GBIAS0			= 0x2F2E;
const IFAMP				= 0x2F2F;

const LNA				= 0x2F30;
const RXMIX				= 0x2F31;
const XOSC5				= 0x2F32;
const XOSC4				= 0x2F33;
const XOSC3				= 0x2F34;
const XOSC2				= 0x2F35;
const XOSC1				= 0x2F36;
const XOSC0				= 0x2F37;
const ANALOG_SPARE		= 0x2F38;
const PA_CFG3			= 0x2F39;

const WOR_TIME1			= 0x2F64;
const WOR_TIME0			= 0x2F65;
const WOR_CAPTURE1		= 0x2F66;
const WOR_CAPTURE0		= 0x2F67;
const BIST				= 0x2F68;
const DCFILTOFFSET_I1	= 0x2F69;
const DCFILTOFFSET_I0	= 0x2F6A;
const DCFILTOFFSET_Q1	= 0x2F6B;
const DCFILTOFFSET_Q0	= 0x2F6C;
const IQIE_I1			= 0x2F6D;
const IQIE_I0			= 0x2F6E;
const IQIE_Q1			= 0x2F6F;
const IQIE_Q0			= 0x2F70;
const RSSI1				= 0x2F71;
const RSSI0				= 0x2F72;
const MARCSTATE			= 0x2F73;
const LQI_VAL			= 0x2F74;
const PQT_SYNC_ERR		= 0x2F75;
const DEM_STATUS		= 0x2F76;
const FREQOFF_EST1		= 0x2F77;
const FREQOFF_EST0		= 0x2F78;
const AGC_GAIN3			= 0x2F79;
const AGC_GAIN2			= 0x2F7A;
const AGC_GAIN1			= 0x2F7B;
const AGC_GAIN0			= 0x2F7C;
const CFM_RX_DATA_OUT	= 0x2F7D;
const CFM_TX_DATA_IN	= 0x2F7E;
const ASK_SOFT_RX_DATA	= 0x2F7F;
const RNDGEN			= 0x2F80;
const MAGN2				= 0x2F81;
const MAGN1				= 0x2F82;
const MAGN0				= 0x2F83;
const ANG1				= 0x2F84;
const ANG0				= 0x2F85;
const CHFILT_I2			= 0x2F86;
const CHFILT_I1			= 0x2F87;
const CHFILT_I0			= 0x2F88;
const CHFILT_Q2			= 0x2F89;
const CHFILT_Q1			= 0x2F8A;
const CHFILT_Q0			= 0x2F8B;
const GPIO_STATUS		= 0x2F8C;
const FSCAL_CTRL		= 0x2F8D;
const PHASE_ADJUST		= 0x2F8E;
const PARTNUMBER		= 0x2F8F;
const PARTVERSION		= 0x2F90;
const SERIAL_STATUS		= 0x2F91;
const MODEM_STATUS1		= 0x2F92;
const MODEM_STATUS0		= 0x2F93;
const MARC_STATUS1		= 0x2F94;
const MARC_STATUS0		= 0x2F95;
const PA_IFAMP_TEST		= 0x2F96;
const FSRF_TEST			= 0x2F97;
const PRE_TEST			= 0x2F98;
const PRE_OVR			= 0x2F99;
const ADC_TEST			= 0x2F9A;
const DVC_TEST			= 0x2F9B;
const ATEST				= 0x2F9C;
const ATEST_LVDS		= 0x2F9D;
const ATEST_MODE		= 0x2F9E;
const XOSC_TEST1		= 0x2F9F;
const XOSC_TEST0		= 0x2FA0;
const AES				= 0x2FA1;
const MDM_TEST			= 0x2FA2;

const RXFIRST			= 0x2FD2;
const TXFIRST			= 0x2FD3;
const RXLAST			= 0x2FD4;
const TXLAST			= 0x2FD5;
const NUM_TXBYTES		= 0x2FD6;
const NUM_RXBYTES		= 0x2FD7;
const FIFO_NUM_TXBYTES	= 0x2FD8;
const FIFO_NUM_RXBYTES	= 0x2FD9;
const RXFIFO_PRE_BUF	= 0x2FDA;
/****************************************************************************************/

/****************************************************************************************/
/* name: 		RegName (Register Name)                                                 */
/* Purpose: 	Converts the register address (adr) to the name (string) of the register*/
/*                                                                                      */
/* Parameter: 	adr: address of the register                                            */
/* Result:		string containing the register name     							    */
/*                                                                                      */
/* Remark:		-                                                                       */
/****************************************************************************************/
function RegName (adr) {  	
	switch (adr){
		case IOCFG3				: return 'IOCFG3'			; break;
		case IOCFG2				: return 'IOCFG2'			; break;
		case IOCFG1				: return 'IOCFG1'			; break;
		case IOCFG0				: return 'IOCFG0'			; break;
		case SYNC3				: return 'SYNC3'			; break;
		case SYNC2				: return 'SYNC2'			; break;
		case SYNC1				: return 'SYNC1'			; break;
		case SYNC0				: return 'SYNC0'			; break;
		case SYNC_CFG1			: return 'SYNC_CFG1'		; break;
		case SYNC_CFG0			: return 'SYNC_CFG0'		; break;
		case DEVIATION_M		: return 'DEVIATION_M'		; break;
		case MODCFG_DEV_E		: return 'MODCFG_DEV_E'		; break;
		case DCFILT_CFG			: return 'DCFILT_CFG'		; break;
		case PREAMBLE_CFG1		: return 'PREAMBLE_CFG1'	; break;
		case PREAMBLE_CFG0		: return 'PREAMBLE_CFG0'	; break;
		case IQIC				: return 'IQIC'				; break;
		case CHAN_BW			: return 'CHAN_BW'			; break;
		case MDMCFG1			: return 'MDMCFG1'			; break;
		case MDMCFG0			: return 'MDMCFG0'			; break;
		case SYMBOL_RATE2		: return 'SYMBOL_RATE2'		; break;
		case SYMBOL_RATE1		: return 'SYMBOL_RATE1'		; break;
		case SYMBOL_RATE0		: return 'SYMBOL_RATE0'		; break;
		case AGC_REF			: return 'AGC_REF'			; break;
		case AGC_CS_THR			: return 'AGC_CS_THR'		; break;
		case AGC_GAIN_ADJUST	: return 'AGC_GAIN_ADJUST'	; break;
		case AGC_CFG3			: return 'AGC_CFG3'			; break;
		case AGC_CFG2			: return 'AGC_CFG2'			; break;
		case AGC_CFG1			: return 'AGC_CFG1'			; break;
		case AGC_CFG0			: return 'AGC_CFG0'			; break;
		case FIFO_CFG			: return 'FIFO_CFG'			; break;
		case DEV_ADDR			: return 'DEV_ADDR'			; break;
		case SETTLING_CFG		: return 'SETTLING_CFG'		; break;
		case FS_CFG				: return 'FS_CFG'			; break;
		case WOR_CFG1			: return 'WOR_CFG1'			; break;
		case WOR_CFG0			: return 'WOR_CFG0'			; break;
		case WOR_EVENT0_MSB		: return 'WOR_EVENT0_MSB'	; break;
		case WOR_EVENT0_LSB		: return 'WOR_EVENT0_LSB'	; break;
		case RXDCM_TIME			: return 'RXDCM_TIME'		; break;
		case PKT_CFG2			: return 'PKT_CFG2'			; break;
		case PKT_CFG1			: return 'PKT_CFG1'			; break;
		case PKT_CFG0			: return 'PKT_CFG0'			; break;
		case RFEND_CFG1			: return 'RFEND_CFG1'		; break;
		case RFEND_CFG0			: return 'RFEND_CFG0'		; break;
		case PA_CFG1			: return 'PA_CFG1'			; break
		case PA_CFG0			: return 'PA_CFG0'			; break;
		case ASK_CFG			: return 'ASK_CFG'			; break;
		case PKT_LEN			: return 'PKT_LEN'			; break;
		case IF_MIX_CFG			: return 'IF_MIX_CFG'		; break;
		case FREQOFF_CFG		: return 'FREQOFF_CFG'		; break;
		case TOC_CFG			: return 'TOC_CFG'			; break;
		case MARC_SPARE			: return 'MARC_SPARE'		; break;
		case ECG_CFG			: return 'ECG_CFG'			; break;
		case MDMCFG2			: return 'MDMCFG2'			; break;
		case EXT_CTRL			: return 'EXT_CTRL'			; break;
		case RCCAL_FINE			: return 'RCCAL_FINE'		; break;
		case RCCAL_COARSE		: return 'RCCAL_COARSE'		; break;
		case RCCAL_OFFSET		: return 'RCCAL_OFFSET'		; break;
		case FREQOFF1			: return 'FREQOFF1'			; break;
		case FREQOFF0			: return 'FREQOFF0'			; break;
		case FREQ2				: return 'FREQ2'			; break;
		case FREQ1				: return 'FREQ1'			; break;
		case FREQ0				: return 'FREQ0'			; break;
		case IF_ADC2			: return 'IF_ADC2'			; break;
		case IF_ADC1			: return 'IF_ADC1'			; break;
		case IF_ADC0			: return 'IF_ADC0'			; break;
		case FS_DIG1			: return 'FS_DIG1'			; break;
		case FS_DIG0			: return 'FS_DIG0'			; break;
		case FS_CAL3			: return 'FS_CAL3'			; break;
		case FS_CAL2			: return 'FS_CAL2'			; break;
		case FS_CAL1			: return 'FS_CAL1'			; break;
		case FS_CAL0			: return 'FS_CAL0'			; break;
		case FS_CHP				: return 'FS_CHP'			; break;
		case FS_DIVTWO			: return 'FS_DIVTWO'		; break;
		case FS_DSM1			: return 'FS_DSM1'			; break;
		case FS_DSM0			: return 'FS_DSM0'			; break;
		case FS_DVC1			: return 'FS_DVC1'			; break;
		case FS_DVC0			: return 'FS_DVC0'			; break;
		case FS_LBI				: return 'FS_LBI'			; break;
		case FS_PFD				: return 'FS_PFD'			; break;
		case FS_PRE				: return 'FS_PRE'			; break;
		case FS_REG_DIV_CML		: return 'FS_REG_DIV_CML'	; break;
		case FS_SPARE			: return 'FS_SPARE'			; break;
		case FS_VCO4			: return 'FS_VCO4'			; break;
		case FS_VCO3			: return 'FS_VCO3'			; break;
		case FS_VCO2			: return 'FS_VCO2'			; break;
		case FS_VCO1			: return 'FS_VCO1'			; break;
		case FS_VCO0			: return 'FS_VCO0'			; break;
		case GBIAS6				: return 'GBIAS6'			; break;
		case GBIAS5				: return 'GBIAS5'			; break;
		case GBIAS4				: return 'GBIAS4'			; break;
		case GBIAS3				: return 'GBIAS3'			; break;
		case GBIAS2				: return 'GBIAS2'			; break;
		case GBIAS1				: return 'GBIAS1'			; break;
		case GBIAS0				: return 'GBIAS0'			; break;
		case IFAMP				: return 'IFAMP'			; break;
		case LNA				: return 'LNA'				; break;
		case RXMIX				: return 'RXMIX'			; break;
		case XOSC5				: return 'XOSC5'			; break;
		case XOSC4				: return 'XOSC4'			; break;
		case XOSC3				: return 'XOSC3'			; break;
		case XOSC2				: return 'XOSC2'			; break;
		case XOSC1				: return 'XOSC1'			; break;
		case XOSC0				: return 'XOSC0'			; break;
		case ANALOG_SPARE		: return 'ANALOG_SPARE'		; break;
		case PA_CFG3			: return 'PA_CFG3'			; break;
		case WOR_TIME1			: return 'WOR_TIME1'		; break;
		case WOR_TIME0			: return 'WOR_TIME0'		; break;
		case WOR_CAPTURE1		: return 'WOR_CAPTURE1'		; break;
		case WOR_CAPTURE0		: return 'WOR_CAPTURE0'		; break;
		case BIST				: return 'BIST'				; break;
		case DCFILTOFFSET_I1	: return 'DCFILTOFFSET_I1'	; break;
		case DCFILTOFFSET_I0	: return 'DCFILTOFFSET_I0'	; break;
		case DCFILTOFFSET_Q1	: return 'DCFILTOFFSET_Q1'	; break;
		case DCFILTOFFSET_Q0	: return 'DCFILTOFFSET_Q0'	; break;
		case IQIE_I1			: return 'IQIE_I1'			; break;
		case IQIE_I0			: return 'IQIE_I0'			; break;
		case IQIE_Q1			: return 'IQIE_Q1'			; break;
		case IQIE_Q0			: return 'IQIE_Q0'			; break;
		case RSSI1				: return 'RSSI1'			; break;
		case RSSI0				: return 'RSSI0'			; break;
		case MARCSTATE			: return 'MARCSTATE'		; break;
		case LQI_VAL			: return 'LQI_VAL'			; break;
		case PQT_SYNC_ERR		: return 'PQT_SYNC_ERR'		; break;
		case DEM_STATUS			: return 'DEM_STATUS'		; break;
		case FREQOFF_EST1		: return 'FREQOFF_EST1'		; break;
		case FREQOFF_EST0		: return 'FREQOFF_EST0'		; break;
		case AGC_GAIN3			: return 'AGC_GAIN3'		; break;
		case AGC_GAIN2			: return 'AGC_GAIN2'		; break;
		case AGC_GAIN1			: return 'AGC_GAIN1'		; break;
		case AGC_GAIN0			: return 'AGC_GAIN0'		; break;
		case CFM_RX_DATA_OUT	: return 'CFM_RX_DATA_OUT'	; break;
		case CFM_TX_DATA_IN		: return 'CFM_TX_DATA_IN'	; break;
		case ASK_SOFT_RX_DATA	: return 'ASK_SOFT_RX_DATA'	; break;
		case RNDGEN				: return 'RNDGEN'			; break;
		case MAGN2				: return 'MAGN2'			; break;
		case MAGN1				: return 'MAGN1'			; break;
		case MAGN0				: return 'MAGN0'			; break;
		case ANG1				: return 'ANG1'				; break;
		case ANG0				: return 'ANG0'				; break;
		case CHFILT_I2			: return 'CHFILT_I2'		; break;
		case CHFILT_I1			: return 'CHFILT_I1'		; break;
		case CHFILT_I0			: return 'CHFILT_I0'		; break;
		case CHFILT_Q2			: return 'CHFILT_Q2'		; break;
		case CHFILT_Q1			: return 'CHFILT_Q1'		; break;
		case CHFILT_Q0			: return 'CHFILT_Q0'		; break;
		case GPIO_STATUS		: return 'GPIO_STATUS'		; break;
		case FSCAL_CTRL			: return 'FSCAL_CTRL'		; break;
		case PHASE_ADJUST		: return 'PHASE_ADJUST'		; break;
		case PARTNUMBER			: return 'PARTNUMBER'		; break;
		case PARTVERSION		: return 'PARTVERSION'		; break;
		case SERIAL_STATUS		: return 'SERIAL_STATUS'	; break;
		case MODEM_STATUS1		: return 'MODEM_STATUS1'	; break;
		case MODEM_STATUS0		: return 'MODEM_STATUS0'	; break;
		case MARC_STATUS1		: return 'MARC_STATUS1'		; break;
		case MARC_STATUS0		: return 'MARC_STATUS0'		; break;
		case PA_IFAMP_TEST		: return 'PA_IFAMP_TEST'	; break;
		case FSRF_TEST			: return 'FSRF_TEST'		; break;
		case PRE_TEST			: return 'PRE_TEST'			; break;
		case PRE_OVR			: return 'PRE_OVR'			; break;
		case ADC_TEST			: return 'ADC_TEST'			; break;
		case DVC_TEST			: return 'DVC_TEST'			; break;
		case ATEST				: return 'ATEST'			; break;
		case ATEST_LVDS			: return 'ATEST_LVDS'		; break;
		case ATEST_MODE			: return 'ATEST_MODE'		; break;
		case XOSC_TEST1			: return 'XOSC_TEST1'		; break;
		case XOSC_TEST0			: return 'XOSC_TEST0'		; break;
		case AES				: return 'AES'				; break;
		case MDM_TEST			: return 'MDM_TEST'			; break;
		case RXFIRST			: return 'RXFIRST'			; break;
		case TXFIRST			: return 'TXFIRST'			; break;
		case RXLAST				: return 'RXLAST'			; break;
		case TXLAST				: return 'TXLAST'			; break;
		case NUM_TXBYTES		: return 'NUM_TXBYTES'		; break;
		case NUM_RXBYTES		: return 'NUM_RXBYTES'		; break;
		case FIFO_NUM_TXBYTES	: return 'FIFO_NUM_TXBYTES'	; break;
		case FIFO_NUM_RXBYTES	: return 'FIFO_NUM_RXBYTES'	; break;
		case RXFIFO_PRE_BUF		: return 'RXFIFO_PRE_BUF'	; break;
		default: console.log("Register not found!"); return '';

	}
}

/****************************************************************************************/
/* name: 		RegAddr (Register Address)                                              */
/* Purpose: 	Converts the register name (str) to the register address                */
/*              of the register                                                         */
/*                                                                                      */
/* Parameter: 	str: name of the register                                               */
/* Result:		register address or -1                       							*/
/*                                                                                      */
/* Remark:		-                                                                       */
/****************************************************************************************/
function RegAddr(str) {
	if (str.localeCompare('IOCFG3')==0) 			return IOCFG3			; else
	if (str.localeCompare('IOCFG2')==0) 			return IOCFG2			; else
	if (str.localeCompare('IOCFG1')==0) 			return IOCFG1			; else
	if (str.localeCompare('IOCFG0')==0) 			return IOCFG0			; else
	if (str.localeCompare('SYNC3')==0) 				return SYNC3			; else
	if (str.localeCompare('SYNC2')==0) 				return SYNC2			; else
	if (str.localeCompare('SYNC1')==0) 				return SYNC1			; else
	if (str.localeCompare('SYNC0')==0) 				return SYNC0			; else
	if (str.localeCompare('SYNC_CFG1')==0) 			return SYNC_CFG1		; else
	if (str.localeCompare('SYNC_CFG0')==0) 			return SYNC_CFG0		; else
	if (str.localeCompare('DEVIATION_M')==0)		return DEVIATION_M		; else
	if (str.localeCompare('MODCFG_DEV_E')==0) 		return MODCFG_DEV_E		; else
	if (str.localeCompare('DCFILT_CFG')==0) 		return DCFILT_CFG		; else
	if (str.localeCompare('PREAMBLE_CFG1')==0) 		return PREAMBLE_CFG1	; else
	if (str.localeCompare('PREAMBLE_CFG0')==0) 		return PREAMBLE_CFG0	; else
	if (str.localeCompare('IQIC')==0) 				return IQIC				; else
	if (str.localeCompare('CHAN_BW')==0) 			return CHAN_BW			; else
	if (str.localeCompare('MDMCFG1')==0) 			return MDMCFG1			; else
	if (str.localeCompare('MDMCFG0')==0) 			return MDMCFG0			; else
	if (str.localeCompare('SYMBOL_RATE2')==0) 		return SYMBOL_RATE2		; else
	if (str.localeCompare('SYMBOL_RATE1')==0) 		return SYMBOL_RATE1		; else
	if (str.localeCompare('SYMBOL_RATE0')==0) 		return SYMBOL_RATE0		; else
	if (str.localeCompare('AGC_REF')==0) 			return AGC_REF			; else
	if (str.localeCompare('AGC_CS_THR')==0) 		return AGC_CS_THR		; else
	if (str.localeCompare('AGC_GAIN_ADJUST')==0)	return AGC_GAIN_ADJUST	; else
	if (str.localeCompare('AGC_CFG3')==0) 			return AGC_CFG3			; else
	if (str.localeCompare('AGC_CFG2')==0) 			return AGC_CFG2			; else
	if (str.localeCompare('AGC_CFG1')==0) 			return AGC_CFG1			; else
	if (str.localeCompare('AGC_CFG0')==0) 			return AGC_CFG0			; else
	if (str.localeCompare('FIFO_CFG')==0) 			return FIFO_CFG			; else
	if (str.localeCompare('DEV_ADDR')==0) 			return DEV_ADDR			; else
	if (str.localeCompare('SETTLING_CFG')==0) 		return SETTLING_CFG		; else
	if (str.localeCompare('FS_CFG')==0) 			return FS_CFG			; else
	if (str.localeCompare('WOR_CFG1')==0) 			return WOR_CFG1			; else
	if (str.localeCompare('WOR_CFG0')==0) 			return WOR_CFG0			; else
	if (str.localeCompare('WOR_EVENT0_MSB')==0) 	return WOR_EVENT0_MSB	; else
	if (str.localeCompare('WOR_EVENT0_LSB')==0) 	return WOR_EVENT0_LSB	; else
	if (str.localeCompare('RXDCM_TIME')==0) 		return RXDCM_TIME		; else
	if (str.localeCompare('PKT_CFG2')==0) 			return PKT_CFG2			; else
	if (str.localeCompare('PKT_CFG1')==0) 			return PKT_CFG1			; else
	if (str.localeCompare('PKT_CFG0')==0)			return PKT_CFG0			; else
	if (str.localeCompare('RFEND_CFG1')==0) 		return RFEND_CFG1		; else
	if (str.localeCompare('RFEND_CFG0')==0) 		return RFEND_CFG0		; else
	if (str.localeCompare('PA_CFG1')==0) 			return PA_CFG1			; else
	if (str.localeCompare('PA_CFG0')==0) 			return PA_CFG0			; else
	if (str.localeCompare('ASK_CFG')==0) 			return ASK_CFG			; else
	if (str.localeCompare('PKT_LEN')==0) 			return PKT_LEN			; else
	
	if (str.localeCompare('IF_MIX_CFG')==0) 		return IF_MIX_CFG		; else
	if (str.localeCompare('FREQOFF_CFG')==0) 		return FREQOFF_CFG		; else
	if (str.localeCompare('TOC_CFG')==0) 			return TOC_CFG			; else
	if (str.localeCompare('MARC_SPARE')==0) 		return MARC_SPARE		; else
	if (str.localeCompare('ECG_CFG')==0) 			return ECG_CFG			; else
	if (str.localeCompare('MDMCFG2')==0) 			return MDMCFG2			; else
	if (str.localeCompare('EXT_CTRL')==0) 			return EXT_CTRL			; else
	if (str.localeCompare('RCCAL_FINE')==0) 		return RCCAL_FINE		; else
	if (str.localeCompare('RCCAL_COARSE')==0) 		return RCCAL_COARSE		; else
	if (str.localeCompare('RCCAL_OFFSET')==0) 		return RCCAL_OFFSET		; else
	if (str.localeCompare('FREQOFF1')==0) 			return FREQOFF1			; else
	if (str.localeCompare('FREQOFF0')==0) 			return FREQOFF0			; else
	if (str.localeCompare('FREQ2')==0) 				return FREQ2			; else
	if (str.localeCompare('FREQ1')==0) 				return FREQ1			; else
	if (str.localeCompare('FREQ0')==0) 				return FREQ0			; else
	if (str.localeCompare('IF_ADC2')==0) 			return IF_ADC2			; else
	if (str.localeCompare('IF_ADC1')==0) 			return IF_ADC1			; else
	if (str.localeCompare('IF_ADC0')==0) 			return IF_ADC0			; else
	if (str.localeCompare('FS_DIG1')==0) 			return FS_DIG1			; else
	if (str.localeCompare('FS_DIG0')==0) 			return FS_DIG0			; else
	if (str.localeCompare('FS_CAL3')==0) 			return FS_CAL3			; else
	if (str.localeCompare('FS_CAL2')==0) 			return FS_CAL2			; else
	if (str.localeCompare('FS_CAL1')==0) 			return FS_CAL1			; else
	if (str.localeCompare('FS_CAL0')==0) 			return FS_CAL0			; else
	if (str.localeCompare('FS_CHP')==0) 			return FS_CHP			; else
	if (str.localeCompare('FS_DIVTWO')==0) 			return FS_DIVTWO		; else
	if (str.localeCompare('FS_DSM1')==0) 			return FS_DSM1			; else
	if (str.localeCompare('FS_DSM0')==0) 			return FS_DSM0			; else
	if (str.localeCompare('FS_DVC1')==0) 			return FS_DVC1			; else
	if (str.localeCompare('FS_DVC0')==0) 			return FS_DVC0			; else
	if (str.localeCompare('FS_LBI')==0) 			return FS_LBI			; else
	if (str.localeCompare('FS_PFD')==0) 			return FS_PFD			; else
	if (str.localeCompare('FS_PRE')==0) 			return FS_PRE			; else
	if (str.localeCompare('FS_REG_DIV_CML')==0) 	return FS_REG_DIV_CML	; else
	if (str.localeCompare('FS_SPARE')==0) 			return FS_SPARE			; else
	if (str.localeCompare('FS_VCO4')==0) 			return FS_VCO4			; else
	if (str.localeCompare('FS_VCO3')==0) 			return FS_VCO3			; else
	if (str.localeCompare('FS_VCO2')==0) 			return FS_VCO2			; else
	if (str.localeCompare('FS_VCO1')==0) 			return FS_VCO1			; else
	if (str.localeCompare('FS_VCO0')==0) 			return FS_VCO0			; else
	if (str.localeCompare('GBIAS6')==0) 			return GBIAS6			; else
	if (str.localeCompare('GBIAS5')==0) 			return GBIAS5			; else
	if (str.localeCompare('GBIAS4')==0) 			return GBIAS4			; else
	if (str.localeCompare('GBIAS3')==0) 			return GBIAS3			; else
	if (str.localeCompare('GBIAS2')==0) 			return GBIAS2			; else
	if (str.localeCompare('GBIAS1')==0) 			return GBIAS1			; else
	if (str.localeCompare('GBIAS0')==0) 			return GBIAS0			; else
	if (str.localeCompare('IFAMP')==0) 				return IFAMP			; else

	if (str.localeCompare('LNA')==0) 				return LNA				; else
	if (str.localeCompare('RXMIX')==0) 				return RXMIX			; else
	if (str.localeCompare('XOSC5')==0) 				return XOSC5			; else
	if (str.localeCompare('XOSC4')==0) 				return XOSC4			; else
	if (str.localeCompare('XOSC3')==0) 				return XOSC3			; else
	if (str.localeCompare('XOSC2')==0) 				return XOSC2			; else
	if (str.localeCompare('XOSC1')==0) 				return XOSC1			; else
	if (str.localeCompare('XOSC0')==0) 				return XOSC0			; else
	if (str.localeCompare('ANALOG_SPARE')==0) 		return ANALOG_SPARE		; else
	if (str.localeCompare('PA_CFG3')==0) 			return PA_CFG3			; else

	if (str.localeCompare('WOR_TIME1')==0) 			return WOR_TIME1		; else
	if (str.localeCompare('WOR_TIME0')==0) 			return WOR_TIME0		; else
	if (str.localeCompare('WOR_CAPTURE1')==0) 		return WOR_CAPTURE1		; else
	if (str.localeCompare('WOR_CAPTURE0')==0) 		return WOR_CAPTURE0		; else
	if (str.localeCompare('BIST')==0) 				return BIST				; else
	if (str.localeCompare('DCFILTOFFSET_I1')==0) 	return DCFILTOFFSET_I1	; else
	if (str.localeCompare('DCFILTOFFSET_I0')==0) 	return DCFILTOFFSET_I0	; else
	if (str.localeCompare('DCFILTOFFSET_Q1')==0) 	return DCFILTOFFSET_Q1	; else
	if (str.localeCompare('DCFILTOFFSET_Q0')==0) 	return DCFILTOFFSET_Q0	; else
	if (str.localeCompare('IQIE_I1')==0) 			return IQIE_I1			; else
	if (str.localeCompare('IQIE_I0')==0) 			return IQIE_I0			; else
	if (str.localeCompare('IQIE_Q1')==0) 			return IQIE_Q1			; else
	if (str.localeCompare('IQIE_Q0')==0) 			return IQIE_Q0			; else
	if (str.localeCompare('RSSI1')==0) 				return RSSI1			; else
	if (str.localeCompare('RSSI0')==0) 				return RSSI0			; else
	if (str.localeCompare('MARCSTATE')==0) 			return MARCSTATE		; else
	if (str.localeCompare('LQI_VAL')==0) 			return LQI_VAL			; else
	if (str.localeCompare('PQT_SYNC_ERR')==0) 		return PQT_SYNC_ERR		; else
	if (str.localeCompare('DEM_STATUS')==0) 		return DEM_STATUS		; else
	if (str.localeCompare('FREQOFF_EST1')==0) 		return FREQOFF_EST1		; else
	if (str.localeCompare('FREQOFF_EST0')==0) 		return FREQOFF_EST0		; else
	if (str.localeCompare('AGC_GAIN3')==0) 			return AGC_GAIN3		; else
	if (str.localeCompare('AGC_GAIN2')==0) 			return AGC_GAIN2		; else
	if (str.localeCompare('AGC_GAIN1')==0) 			return AGC_GAIN1		; else
	if (str.localeCompare('AGC_GAIN0')==0) 			return AGC_GAIN0		; else
	if (str.localeCompare('CFM_RX_DATA_OUT')==0) 	return CFM_RX_DATA_OUT	; else
	if (str.localeCompare('CFM_TX_DATA_IN')==0) 	return CFM_TX_DATA_IN	; else
	if (str.localeCompare('ASK_SOFT_RX_DATA')==0) 	return ASK_SOFT_RX_DATA	; else
	if (str.localeCompare('RNDGEN')==0) 			return RNDGEN			; else
	if (str.localeCompare('MAGN2')==0) 				return MAGN2			; else
	if (str.localeCompare('MAGN1')==0) 				return MAGN1			; else
	if (str.localeCompare('MAGN0')==0) 				return MAGN0			; else
	if (str.localeCompare('ANG1')==0) 				return ANG1				; else
	if (str.localeCompare('ANG0')==0) 				return ANG0				; else
	if (str.localeCompare('CHFILT_I2')==0) 			return CHFILT_I2		; else
	if (str.localeCompare('CHFILT_I1')==0) 			return CHFILT_I1		; else
	if (str.localeCompare('CHFILT_I0')==0) 			return CHFILT_I0		; else
	if (str.localeCompare('CHFILT_Q2')==0) 			return CHFILT_Q2		; else
	if (str.localeCompare('CHFILT_Q1')==0) 			return CHFILT_Q1		; else
	if (str.localeCompare('CHFILT_Q0')==0) 			return CHFILT_Q0		; else
	if (str.localeCompare('GPIO_STATUS')==0) 		return GPIO_STATUS		; else
	if (str.localeCompare('FSCAL_CTRL')==0) 		return FSCAL_CTRL		; else
	if (str.localeCompare('PHASE_ADJUST')==0) 		return PHASE_ADJUST		; else
	if (str.localeCompare('PARTNUMBER')==0) 		return PARTNUMBER		; else
	if (str.localeCompare('PARTVERSION')==0) 		return PARTVERSION		; else
	if (str.localeCompare('SERIAL_STATUS')==0) 		return SERIAL_STATUS	; else
	if (str.localeCompare('MODEM_STATUS1')==0) 		return MODEM_STATUS1	; else
	if (str.localeCompare('MODEM_STATUS0')==0) 		return MODEM_STATUS0	; else
	if (str.localeCompare('MARC_STATUS1')==0) 		return MARC_STATUS1		; else
	if (str.localeCompare('MARC_STATUS0')==0) 		return MARC_STATUS0		; else
	if (str.localeCompare('PA_IFAMP_TEST')==0) 		return PA_IFAMP_TEST	; else
	if (str.localeCompare('FSRF_TEST')==0) 			return FSRF_TEST		; else
	if (str.localeCompare('PRE_TEST')==0) 			return PRE_TEST			; else
	if (str.localeCompare('PRE_OVR')==0) 			return PRE_OVR			; else
	if (str.localeCompare('ADC_TEST')==0) 			return ADC_TEST			; else
	if (str.localeCompare('DVC_TEST')==0) 			return DVC_TEST			; else
	if (str.localeCompare('ATEST')==0) 				return ATEST			; else
	if (str.localeCompare('ATEST_LVDS')==0) 		return ATEST_LVDS		; else
	if (str.localeCompare('ATEST_MODE')==0) 		return ATEST_MODE		; else
	if (str.localeCompare('XOSC_TEST1')==0) 		return XOSC_TEST1		; else
	if (str.localeCompare('XOSC_TEST0')==0) 		return XOSC_TEST0		; else
	if (str.localeCompare('AES')==0) 				return AES				; else
	if (str.localeCompare('MDM_TEST')==0) 			return MDM_TEST			; else

	if (str.localeCompare('RXFIRST')==0) 			return RXFIRST			; else
	if (str.localeCompare('TXFIRST')==0) 			return TXFIRST			; else
	if (str.localeCompare('RXLAST')==0) 			return RXLAST			; else
	if (str.localeCompare('TXLAST')==0) 			return TXLAST			; else
	if (str.localeCompare('NUM_TXBYTES')==0) 		return NUM_TXBYTES		; else
	if (str.localeCompare('NUM_RXBYTES')==0) 		return NUM_RXBYTES		; else
	if (str.localeCompare('FIFO_NUM_TXBYTES')==0) 	return FIFO_NUM_TXBYTES	; else
	if (str.localeCompare('FIFO_NUM_RXBYTES')==0) 	return FIFO_NUM_RXBYTES	; else
	if (str.localeCompare('RXFIFO_PRE_BUF')==0) 	return RXFIFO_PRE_BUF	; else
	
	return -1;
}


function destroyClickedElement(event)
{
    document.body.removeChild(event.target);
}

/****************************************************************************************/
/* name: 		SaveReg (Save Register)                                                 */
/* Purpose: 	writes the current register values to a file                            */
/*                                                                                      */
/* Parameter: 	description : a description of this configuration                       */
/*				filename	: the filename to store the configuration                   */
/* Result:		-                                           							*/
/*                                                                                      */
/* Remark:		-                                                                       */
/****************************************************************************************/
function SaveReg(description, filename) {
	/* save the description in the reg_profile array */
	var reg_profile = ["Description ", description + "\n"];

	/* registers */
	var iocfg3				= document.getElementById(RegName(IOCFG3			));
	var iocfg2				= document.getElementById(RegName(IOCFG2			));
	var iocfg1				= document.getElementById(RegName(IOCFG1			));
	var iocfg0				= document.getElementById(RegName(IOCFG0			));
	var sync3				= document.getElementById(RegName(SYNC3				));	
	var sync2				= document.getElementById(RegName(SYNC2				));	
	var sync1				= document.getElementById(RegName(SYNC1				));	
	var sync0				= document.getElementById(RegName(SYNC0				));	
	var sync_cfg1			= document.getElementById(RegName(SYNC_CFG1			));
	var sync_cfg0			= document.getElementById(RegName(SYNC_CFG0			));
	var deviation_m			= document.getElementById(RegName(DEVIATION_M		));
	var modcfg_dev_e		= document.getElementById(RegName(MODCFG_DEV_E		));
	var dcfilt_cfg			= document.getElementById(RegName(DCFILT_CFG		));
	var preamble_cfg1		= document.getElementById(RegName(PREAMBLE_CFG1		));
	var preamble_cfg0		= document.getElementById(RegName(PREAMBLE_CFG0		));
	var iqic				= document.getElementById(RegName(IQIC				));	
	var chan_bw				= document.getElementById(RegName(CHAN_BW			));	
	var mdmcfg1				= document.getElementById(RegName(MDMCFG1			));	
	var mdmcfg0				= document.getElementById(RegName(MDMCFG0			));	
	var symbol_rate2		= document.getElementById(RegName(SYMBOL_RATE2		));
	var symbol_rate1		= document.getElementById(RegName(SYMBOL_RATE1		));
	var symbol_rate0		= document.getElementById(RegName(SYMBOL_RATE0		));
	var agc_ref				= document.getElementById(RegName(AGC_REF			));	
	var agc_cs_thr			= document.getElementById(RegName(AGC_CS_THR		));
	var agc_gain_adjust		= document.getElementById(RegName(AGC_GAIN_ADJUST	));
	var agc_cfg3			= document.getElementById(RegName(AGC_CFG3			));	
	var agc_cfg2			= document.getElementById(RegName(AGC_CFG2			));	
	var agc_cfg1			= document.getElementById(RegName(AGC_CFG1			));	
	var agc_cfg0			= document.getElementById(RegName(AGC_CFG0			));	
	var fifo_cfg			= document.getElementById(RegName(FIFO_CFG			));	
	var dev_addr			= document.getElementById(RegName(DEV_ADDR			));	
	var settling_cfg		= document.getElementById(RegName(SETTLING_CFG		));
	var fs_cfg				= document.getElementById(RegName(FS_CFG			));
	var wor_cfg1			= document.getElementById(RegName(WOR_CFG1			));	
	var wor_cfg0			= document.getElementById(RegName(WOR_CFG0			));	
	var wor_event0_msb		= document.getElementById(RegName(WOR_EVENT0_MSB	));
	var wor_event0_lsb		= document.getElementById(RegName(WOR_EVENT0_LSB	));
	var rxdcm_time			= document.getElementById(RegName(RXDCM_TIME		));
	var pkt_cfg2			= document.getElementById(RegName(PKT_CFG2			));	
	var pkt_cfg1			= document.getElementById(RegName(PKT_CFG1			));	
	var pkt_cfg0			= document.getElementById(RegName(PKT_CFG0			));	
	var rfend_cfg1			= document.getElementById(RegName(RFEND_CFG1		));
	var rfend_cfg0			= document.getElementById(RegName(RFEND_CFG0		));
	var pa_cfg1				= document.getElementById(RegName(PA_CFG1			));	
	var pa_cfg0				= document.getElementById(RegName(PA_CFG0			));	
	var ask_cfg				= document.getElementById(RegName(ASK_CFG			));	
	var pkt_len				= document.getElementById(RegName(PKT_LEN			));	
	var if_mix_cfg			= document.getElementById(RegName(IF_MIX_CFG		));
	var freqoff_cfg			= document.getElementById(RegName(FREQOFF_CFG		));
	var toc_cfg				= document.getElementById(RegName(TOC_CFG			));	
	var marc_spare			= document.getElementById(RegName(MARC_SPARE		));
	var ecg_cfg				= document.getElementById(RegName(ECG_CFG			));	
	var mdmcfg2				= document.getElementById(RegName(MDMCFG2			));	
	var ext_ctrl			= document.getElementById(RegName(EXT_CTRL			));	
	var rccal_fine			= document.getElementById(RegName(RCCAL_FINE		));
	var rccal_coarse		= document.getElementById(RegName(RCCAL_COARSE		));
	var rccal_offset		= document.getElementById(RegName(RCCAL_OFFSET		));
	var freqoff1			= document.getElementById(RegName(FREQOFF1			));	
	var freqoff0			= document.getElementById(RegName(FREQOFF0			));	
	var freq2				= document.getElementById(RegName(FREQ2				));	
	var freq1				= document.getElementById(RegName(FREQ1				));	
	var freq0				= document.getElementById(RegName(FREQ0				));	
	var if_adc2				= document.getElementById(RegName(IF_ADC2			));	
	var if_adc1				= document.getElementById(RegName(IF_ADC1			));	
	var if_adc0				= document.getElementById(RegName(IF_ADC0			));	
	var fs_dig1				= document.getElementById(RegName(FS_DIG1			));	
	var fs_dig0				= document.getElementById(RegName(FS_DIG0			));	
	var fs_cal3				= document.getElementById(RegName(FS_CAL3			));	
	var fs_cal2				= document.getElementById(RegName(FS_CAL2			));	
	var fs_cal1				= document.getElementById(RegName(FS_CAL1			));	
	var fs_cal0				= document.getElementById(RegName(FS_CAL0			));	
	var fs_chp				= document.getElementById(RegName(FS_CHP			));
	var fs_divtwo			= document.getElementById(RegName(FS_DIVTWO			));
	var fs_dsm1				= document.getElementById(RegName(FS_DSM1			));	
	var fs_dsm0				= document.getElementById(RegName(FS_DSM0			));	
	var fs_dvc1				= document.getElementById(RegName(FS_DVC1			));	
	var fs_dvc0				= document.getElementById(RegName(FS_DVC0			));	
	var fs_lbi				= document.getElementById(RegName(FS_LBI			));
	var fs_pfd				= document.getElementById(RegName(FS_PFD			));
	var fs_pre				= document.getElementById(RegName(FS_PRE			));
	var fs_reg_div_cml		= document.getElementById(RegName(FS_REG_DIV_CML	));
	var fs_spare			= document.getElementById(RegName(FS_SPARE			));	
	var fs_vco4				= document.getElementById(RegName(FS_VCO4			));	
	var fs_vco3				= document.getElementById(RegName(FS_VCO3			));	
	var fs_vco2				= document.getElementById(RegName(FS_VCO2			));	
	var fs_vco1				= document.getElementById(RegName(FS_VCO1			));	
	var fs_vco0				= document.getElementById(RegName(FS_VCO0			));	
	var gbias6				= document.getElementById(RegName(GBIAS6			));
	var gbias5				= document.getElementById(RegName(GBIAS5			));
	var gbias4				= document.getElementById(RegName(GBIAS4			));
	var gbias3				= document.getElementById(RegName(GBIAS3			));
	var gbias2				= document.getElementById(RegName(GBIAS2			));
	var gbias1				= document.getElementById(RegName(GBIAS1			));
	var gbias0				= document.getElementById(RegName(GBIAS0			));
	var ifamp				= document.getElementById(RegName(IFAMP				));	
	var lna					= document.getElementById(RegName(LNA				));	
	var rxmix				= document.getElementById(RegName(RXMIX				));	
	var xosc5				= document.getElementById(RegName(XOSC5				));	
	var xosc4				= document.getElementById(RegName(XOSC4				));	
	var xosc3				= document.getElementById(RegName(XOSC3				));	
	var xosc2				= document.getElementById(RegName(XOSC2				));	
	var xosc1				= document.getElementById(RegName(XOSC1				));	
	var xosc0				= document.getElementById(RegName(XOSC0				));	
	var analog_spare		= document.getElementById(RegName(ANALOG_SPARE		));
	var pa_cfg3				= document.getElementById(RegName(PA_CFG3			));	
	var wor_time1			= document.getElementById(RegName(WOR_TIME1			));
	var wor_time0			= document.getElementById(RegName(WOR_TIME0			));
	var wor_capture1		= document.getElementById(RegName(WOR_CAPTURE1		));
	var wor_capture0		= document.getElementById(RegName(WOR_CAPTURE0		));
	var bist				= document.getElementById(RegName(BIST				));	
	var dcfiltoffset_i1		= document.getElementById(RegName(DCFILTOFFSET_I1	));
	var dcfiltoffset_i0		= document.getElementById(RegName(DCFILTOFFSET_I0	));
	var dcfiltoffset_q1		= document.getElementById(RegName(DCFILTOFFSET_Q1	));
	var dcfiltoffset_q0		= document.getElementById(RegName(DCFILTOFFSET_Q0	));
	var iqie_i1				= document.getElementById(RegName(IQIE_I1			));	
	var iqie_i0				= document.getElementById(RegName(IQIE_I0			));	
	var iqie_q1				= document.getElementById(RegName(IQIE_Q1			));	
	var iqie_q0				= document.getElementById(RegName(IQIE_Q0			));	
	var rssi1				= document.getElementById(RegName(RSSI1				));	
	var rssi0				= document.getElementById(RegName(RSSI0				));	
	var marcstate			= document.getElementById(RegName(MARCSTATE			));
	var lqi_val				= document.getElementById(RegName(LQI_VAL			));	
	var pqt_sync_err		= document.getElementById(RegName(PQT_SYNC_ERR		));
	var dem_status			= document.getElementById(RegName(DEM_STATUS		));
	var freqoff_est1		= document.getElementById(RegName(FREQOFF_EST1		));
	var freqoff_est0		= document.getElementById(RegName(FREQOFF_EST0		));
	var agc_gain3			= document.getElementById(RegName(AGC_GAIN3			));
	var agc_gain2			= document.getElementById(RegName(AGC_GAIN2			));
	var agc_gain1			= document.getElementById(RegName(AGC_GAIN1			));
	var agc_gain0			= document.getElementById(RegName(AGC_GAIN0			));
	var cfm_rx_data_out		= document.getElementById(RegName(CFM_RX_DATA_OUT	));
	var cfm_tx_data_in		= document.getElementById(RegName(CFM_TX_DATA_IN	));
	var ask_soft_rx_data	= document.getElementById(RegName(ASK_SOFT_RX_DATA	));
	var rndgen				= document.getElementById(RegName(RNDGEN			));
	var magn2				= document.getElementById(RegName(MAGN2				));	
	var magn1				= document.getElementById(RegName(MAGN1				));	
	var magn0				= document.getElementById(RegName(MAGN0				));	
	var ang1				= document.getElementById(RegName(ANG1				));	
	var ang0				= document.getElementById(RegName(ANG0				));	
	var chfilt_i2			= document.getElementById(RegName(CHFILT_I2			));
	var chfilt_i1			= document.getElementById(RegName(CHFILT_I1			));
	var chfilt_i0			= document.getElementById(RegName(CHFILT_I0			));
	var chfilt_q2			= document.getElementById(RegName(CHFILT_Q2			));
	var chfilt_q1			= document.getElementById(RegName(CHFILT_Q1			));
	var chfilt_q0			= document.getElementById(RegName(CHFILT_Q0			));
	var gpio_status			= document.getElementById(RegName(GPIO_STATUS		));
	var fscal_ctrl			= document.getElementById(RegName(FSCAL_CTRL		));
	var phase_adjust		= document.getElementById(RegName(PHASE_ADJUST		));
	var partnumber			= document.getElementById(RegName(PARTNUMBER		));
	var partversion			= document.getElementById(RegName(PARTVERSION		));
	var serial_status		= document.getElementById(RegName(SERIAL_STATUS		));
	var modem_status1		= document.getElementById(RegName(MODEM_STATUS1		));
	var modem_status0		= document.getElementById(RegName(MODEM_STATUS0		));
	var marc_status1		= document.getElementById(RegName(MARC_STATUS1		));
	var marc_status0		= document.getElementById(RegName(MARC_STATUS0		));
	var pa_ifamp_test		= document.getElementById(RegName(PA_IFAMP_TEST		));
	var fsrf_test			= document.getElementById(RegName(FSRF_TEST			));
	var pre_test			= document.getElementById(RegName(PRE_TEST			));	
	var pre_ovr				= document.getElementById(RegName(PRE_OVR			));	
	var adc_test			= document.getElementById(RegName(ADC_TEST			));	
	var dvc_test			= document.getElementById(RegName(DVC_TEST			));	
	var atest				= document.getElementById(RegName(ATEST				));	
	var atest_lvds			= document.getElementById(RegName(ATEST_LVDS		));
	var atest_mode			= document.getElementById(RegName(ATEST_MODE		));
	var xosc_test1			= document.getElementById(RegName(XOSC_TEST1		));
	var xosc_test0			= document.getElementById(RegName(XOSC_TEST0		));
	var aes					= document.getElementById(RegName(AES				));	
	var mdm_test			= document.getElementById(RegName(MDM_TEST			));	
	var rxfirst				= document.getElementById(RegName(RXFIRST			));	
	var txfirst				= document.getElementById(RegName(TXFIRST			));	
	var rxlast				= document.getElementById(RegName(RXLAST			));
	var txlast				= document.getElementById(RegName(TXLAST			));
	var num_txbytes			= document.getElementById(RegName(NUM_TXBYTES		));
	var num_rxbytes			= document.getElementById(RegName(NUM_RXBYTES		));
	var fifo_num_txbytes	= document.getElementById(RegName(FIFO_NUM_TXBYTES	));
	var fifo_num_rxbytes	= document.getElementById(RegName(FIFO_NUM_RXBYTES	));
	var rxfifo_pre_buf		= document.getElementById(RegName(RXFIFO_PRE_BUF	));
	
	/* append all register values to the reg_profile array */
	reg_profile.push([RegName(IOCFG3			) + " " + iocfg3.value + "\n"   	   ]);			
	reg_profile.push([RegName(IOCFG2			) + " " + iocfg2.value + "\n"		   ]);			
	reg_profile.push([RegName(IOCFG1			) + " " + iocfg1.value + "\n"		   ]);			
	reg_profile.push([RegName(IOCFG0			) + " " + iocfg0.value + "\n"		   ]);			
	reg_profile.push([RegName(SYNC3				) + " " + sync3.value + "\n"		   ]);			
	reg_profile.push([RegName(SYNC2				) + " " + sync2.value + "\n"		   ]);			
	reg_profile.push([RegName(SYNC1				) + " " + sync1.value + "\n"		   ]);			
	reg_profile.push([RegName(SYNC0				) + " " + sync0.value + "\n"		   ]);			
	reg_profile.push([RegName(SYNC_CFG1			) + " " + sync_cfg1.value + "\n"	   ]);		
	reg_profile.push([RegName(SYNC_CFG0			) + " " + sync_cfg0.value + "\n"	   ]);		
	reg_profile.push([RegName(DEVIATION_M		) + " " + deviation_m.value + "\n"	   ]);		
	reg_profile.push([RegName(MODCFG_DEV_E		) + " " + modcfg_dev_e.value + "\n"	   ]);		
	reg_profile.push([RegName(DCFILT_CFG		) + " " + dcfilt_cfg.value + "\n"	   ]);		
	reg_profile.push([RegName(PREAMBLE_CFG1		) + " " + preamble_cfg1.value + "\n"   ]);	
	reg_profile.push([RegName(PREAMBLE_CFG0		) + " " + preamble_cfg0.value + "\n"   ]);	
	reg_profile.push([RegName(IQIC				) + " " + iqic.value + "\n"			   ]);				
	reg_profile.push([RegName(CHAN_BW			) + " " + chan_bw.value + "\n"		   ]);			
	reg_profile.push([RegName(MDMCFG1			) + " " + mdmcfg1.value + "\n"		   ]);			
	reg_profile.push([RegName(MDMCFG0			) + " " + mdmcfg0.value + "\n"		   ]);			
	reg_profile.push([RegName(SYMBOL_RATE2		) + " " + symbol_rate2.value + "\n"	   ]);		
	reg_profile.push([RegName(SYMBOL_RATE1		) + " " + symbol_rate1.value + "\n"	   ]);		
	reg_profile.push([RegName(SYMBOL_RATE0		) + " " + symbol_rate0.value + "\n"	   ]);		
	reg_profile.push([RegName(AGC_REF			) + " " + agc_ref.value + "\n"		   ]);			
	reg_profile.push([RegName(AGC_CS_THR		) + " " + agc_cs_thr.value + "\n"	   ]);		
	reg_profile.push([RegName(AGC_GAIN_ADJUST	) + " " + agc_gain_adjust.value + "\n" ]);	
	reg_profile.push([RegName(AGC_CFG3			) + " " + agc_cfg3.value + "\n"		   ]);			
	reg_profile.push([RegName(AGC_CFG2			) + " " + agc_cfg2.value + "\n"		   ]);			
	reg_profile.push([RegName(AGC_CFG1			) + " " + agc_cfg1.value + "\n"		   ]);			
	reg_profile.push([RegName(AGC_CFG0			) + " " + agc_cfg0.value + "\n"		   ]);			
	reg_profile.push([RegName(FIFO_CFG			) + " " + fifo_cfg.value + "\n"		   ]);			
	reg_profile.push([RegName(DEV_ADDR			) + " " + dev_addr.value + "\n"		   ]);			
	reg_profile.push([RegName(SETTLING_CFG		) + " " + settling_cfg.value + "\n"	   ]);		
	reg_profile.push([RegName(FS_CFG			) + " " + fs_cfg.value + "\n"		   ]);			
	reg_profile.push([RegName(WOR_CFG1			) + " " + wor_cfg1.value + "\n"		   ]);			
	reg_profile.push([RegName(WOR_CFG0			) + " " + wor_cfg0.value + "\n"		   ]);			
	reg_profile.push([RegName(WOR_EVENT0_MSB	) + " " + wor_event0_msb.value + "\n"  ]);	
	reg_profile.push([RegName(WOR_EVENT0_LSB	) + " " + wor_event0_lsb.value + "\n"  ]);	
	reg_profile.push([RegName(RXDCM_TIME		) + " " + rxdcm_time.value + "\n"	   ]);		
	reg_profile.push([RegName(PKT_CFG2			) + " " + pkt_cfg2.value + "\n"		   ]);			
	reg_profile.push([RegName(PKT_CFG1			) + " " + pkt_cfg1.value + "\n"		   ]);			
	reg_profile.push([RegName(PKT_CFG0			) + " " + pkt_cfg0.value + "\n"		   ]);			
	reg_profile.push([RegName(RFEND_CFG1		) + " " + rfend_cfg1.value + "\n"	   ]);		
	reg_profile.push([RegName(RFEND_CFG0		) + " " + rfend_cfg0.value + "\n"	   ]);		
	reg_profile.push([RegName(PA_CFG1			) + " " + pa_cfg1.value + "\n"		   ]);			
	reg_profile.push([RegName(PA_CFG0			) + " " + pa_cfg0.value + "\n"		   ]);			
	reg_profile.push([RegName(ASK_CFG			) + " " + ask_cfg.value + "\n"		   ]);			
	reg_profile.push([RegName(PKT_LEN			) + " " + pkt_len.value + "\n"		   ]);			
	reg_profile.push([RegName(IF_MIX_CFG		) + " " + if_mix_cfg.value + "\n"	   ]);		
	reg_profile.push([RegName(FREQOFF_CFG		) + " " + freqoff_cfg.value + "\n"	   ]);		
	reg_profile.push([RegName(TOC_CFG			) + " " + toc_cfg.value + "\n"		   ]);			
	reg_profile.push([RegName(MARC_SPARE		) + " " + marc_spare.value + "\n"	   ]);		
	reg_profile.push([RegName(ECG_CFG			) + " " + ecg_cfg.value + "\n"		   ]);			
	reg_profile.push([RegName(MDMCFG2			) + " " + mdmcfg2.value + "\n"		   ]);			
	reg_profile.push([RegName(EXT_CTRL			) + " " + ext_ctrl.value + "\n"		   ]);			
	reg_profile.push([RegName(RCCAL_FINE		) + " " + rccal_fine.value + "\n"	   ]);		
	reg_profile.push([RegName(RCCAL_COARSE		) + " " + rccal_coarse.value + "\n"	   ]);		
	reg_profile.push([RegName(RCCAL_OFFSET		) + " " + rccal_offset.value + "\n"	   ]);		
	reg_profile.push([RegName(FREQOFF1			) + " " + freqoff1.value + "\n"		   ]);			
	reg_profile.push([RegName(FREQOFF0			) + " " + freqoff0.value + "\n"		   ]);			
	reg_profile.push([RegName(FREQ2				) + " " + freq2.value + "\n"		   ]);			
	reg_profile.push([RegName(FREQ1				) + " " + freq1.value + "\n"		   ]);			
	reg_profile.push([RegName(FREQ0				) + " " + freq0.value + "\n"		   ]);			
	reg_profile.push([RegName(IF_ADC2			) + " " + if_adc2.value + "\n"		   ]);			
	reg_profile.push([RegName(IF_ADC1			) + " " + if_adc1.value + "\n"		   ]);			
	reg_profile.push([RegName(IF_ADC0			) + " " + if_adc0.value + "\n"		   ]);			
	reg_profile.push([RegName(FS_DIG1			) + " " + fs_dig1.value + "\n"		   ]);			
	reg_profile.push([RegName(FS_DIG0			) + " " + fs_dig0.value + "\n"		   ]);			
	reg_profile.push([RegName(FS_CAL3			) + " " + fs_cal3.value + "\n"		   ]);			
	reg_profile.push([RegName(FS_CAL2			) + " " + fs_cal2.value + "\n"		   ]);			
	reg_profile.push([RegName(FS_CAL1			) + " " + fs_cal1.value + "\n"		   ]);			
	reg_profile.push([RegName(FS_CAL0			) + " " + fs_cal0.value + "\n"		   ]);			
	reg_profile.push([RegName(FS_CHP			) + " " + fs_chp.value + "\n"		   ]);			
	reg_profile.push([RegName(FS_DIVTWO			) + " " + fs_divtwo.value + "\n"	   ]);		
	reg_profile.push([RegName(FS_DSM1			) + " " + fs_dsm1.value + "\n"		   ]);			
	reg_profile.push([RegName(FS_DSM0			) + " " + fs_dsm0.value + "\n"		   ]);			
	reg_profile.push([RegName(FS_DVC1			) + " " + fs_dvc1.value + "\n"		   ]);			
	reg_profile.push([RegName(FS_DVC0			) + " " + fs_dvc0.value + "\n"		   ]);			
	reg_profile.push([RegName(FS_LBI			) + " " + fs_lbi.value + "\n"		   ]);			
	reg_profile.push([RegName(FS_PFD			) + " " + fs_pfd.value + "\n"		   ]);			
	reg_profile.push([RegName(FS_PRE			) + " " + fs_pre.value + "\n"		   ]);			
	reg_profile.push([RegName(FS_REG_DIV_CML	) + " " + fs_reg_div_cml.value + "\n"  ]);	
	reg_profile.push([RegName(FS_SPARE			) + " " + fs_spare.value + "\n"		   ]);			
	reg_profile.push([RegName(FS_VCO4			) + " " + fs_vco4.value + "\n"		   ]);			
	reg_profile.push([RegName(FS_VCO3			) + " " + fs_vco3.value + "\n"		   ]);			
	reg_profile.push([RegName(FS_VCO2			) + " " + fs_vco2.value + "\n"		   ]);			
	reg_profile.push([RegName(FS_VCO1			) + " " + fs_vco1.value + "\n"		   ]);			
	reg_profile.push([RegName(FS_VCO0			) + " " + fs_vco0.value + "\n"		   ]);			
	reg_profile.push([RegName(GBIAS6			) + " " + gbias6.value + "\n"		   ]);			
	reg_profile.push([RegName(GBIAS5			) + " " + gbias5.value + "\n"		   ]);			
	reg_profile.push([RegName(GBIAS4			) + " " + gbias4.value + "\n"		   ]);			
	reg_profile.push([RegName(GBIAS3			) + " " + gbias3.value + "\n"		   ]);			
	reg_profile.push([RegName(GBIAS2			) + " " + gbias2.value + "\n"		   ]);			
	reg_profile.push([RegName(GBIAS1			) + " " + gbias1.value + "\n"		   ]);			
	reg_profile.push([RegName(GBIAS0			) + " " + gbias0.value + "\n"		   ]);			
	reg_profile.push([RegName(IFAMP				) + " " + ifamp.value + "\n"		   ]);			
	reg_profile.push([RegName(LNA				) + " " + lna.value + "\n"			   ]);				
	reg_profile.push([RegName(RXMIX				) + " " + rxmix.value + "\n"		   ]);			
	reg_profile.push([RegName(XOSC5				) + " " + xosc5.value + "\n"		   ]);			
	reg_profile.push([RegName(XOSC4				) + " " + xosc4.value + "\n"		   ]);			
	reg_profile.push([RegName(XOSC3				) + " " + xosc3.value + "\n"		   ]);			
	reg_profile.push([RegName(XOSC2				) + " " + xosc2.value + "\n"		   ]);			
	reg_profile.push([RegName(XOSC1				) + " " + xosc1.value + "\n"		   ]);			
	reg_profile.push([RegName(XOSC0				) + " " + xosc0.value + "\n"		   ]);			
	reg_profile.push([RegName(ANALOG_SPARE		) + " " + analog_spare.value + "\n"	   ]);		
	reg_profile.push([RegName(PA_CFG3			) + " " + pa_cfg3.value + "\n"		   ]);			
	reg_profile.push([RegName(WOR_TIME1			) + " " + wor_time1.value + "\n"	   ]);		
	reg_profile.push([RegName(WOR_TIME0			) + " " + wor_time0.value + "\n"	   ]);		
	reg_profile.push([RegName(WOR_CAPTURE1		) + " " + wor_capture1.value + "\n"	   ]);		
	reg_profile.push([RegName(WOR_CAPTURE0		) + " " + wor_capture0.value + "\n"	   ]);		
	reg_profile.push([RegName(BIST				) + " " + bist.value + "\n"			   ]);				
	reg_profile.push([RegName(DCFILTOFFSET_I1	) + " " + dcfiltoffset_i1.value + "\n" ]);	
	reg_profile.push([RegName(DCFILTOFFSET_I0	) + " " + dcfiltoffset_i0.value + "\n" ]);	
	reg_profile.push([RegName(DCFILTOFFSET_Q1	) + " " + dcfiltoffset_q1.value + "\n" ]);	
	reg_profile.push([RegName(DCFILTOFFSET_Q0	) + " " + dcfiltoffset_q0.value + "\n" ]);	
	reg_profile.push([RegName(IQIE_I1			) + " " + iqie_i1.value + "\n"		   ]);			
	reg_profile.push([RegName(IQIE_I0			) + " " + iqie_i0.value + "\n"		   ]);			
	reg_profile.push([RegName(IQIE_Q1			) + " " + iqie_q1.value + "\n"		   ]);			
	reg_profile.push([RegName(IQIE_Q0			) + " " + iqie_q0.value + "\n"		   ]);			
	reg_profile.push([RegName(RSSI1				) + " " + rssi1.value + "\n"		   ]);			
	reg_profile.push([RegName(RSSI0				) + " " + rssi0.value + "\n"		   ]);			
	reg_profile.push([RegName(MARCSTATE			) + " " + marcstate.value + "\n"	   ]);		
	reg_profile.push([RegName(LQI_VAL			) + " " + lqi_val.value + "\n"		   ]);			
	reg_profile.push([RegName(PQT_SYNC_ERR		) + " " + pqt_sync_err.value + "\n"	   ]);		
	reg_profile.push([RegName(DEM_STATUS		) + " " + dem_status.value + "\n"	   ]);		
	reg_profile.push([RegName(FREQOFF_EST1		) + " " + freqoff_est1.value + "\n"	   ]);		
	reg_profile.push([RegName(FREQOFF_EST0		) + " " + freqoff_est0.value + "\n"	   ]);		
	reg_profile.push([RegName(AGC_GAIN3			) + " " + agc_gain3.value + "\n"	   ]);		
	reg_profile.push([RegName(AGC_GAIN2			) + " " + agc_gain2.value + "\n"	   ]);		
	reg_profile.push([RegName(AGC_GAIN1			) + " " + agc_gain1.value + "\n"	   ]);		
	reg_profile.push([RegName(AGC_GAIN0			) + " " + agc_gain0.value + "\n"	   ]);		
	reg_profile.push([RegName(CFM_RX_DATA_OUT	) + " " + cfm_rx_data_out.value + "\n" ]);	
	reg_profile.push([RegName(CFM_TX_DATA_IN	) + " " + cfm_tx_data_in.value + "\n"  ]);	
	reg_profile.push([RegName(ASK_SOFT_RX_DATA	) + " " + ask_soft_rx_data.value + "\n"]);
	reg_profile.push([RegName(RNDGEN			) + " " + rndgen.value + "\n"		   ]);			
	reg_profile.push([RegName(MAGN2				) + " " + magn2.value + "\n"		   ]);			
	reg_profile.push([RegName(MAGN1				) + " " + magn1.value + "\n"		   ]);			
	reg_profile.push([RegName(MAGN0				) + " " + magn0.value + "\n"		   ]);			
	reg_profile.push([RegName(ANG1				) + " " + ang1.value + "\n"			   ]);				
	reg_profile.push([RegName(ANG0				) + " " + ang0.value + "\n"			   ]);				
	reg_profile.push([RegName(CHFILT_I2			) + " " + chfilt_i2.value + "\n"	   ]);		
	reg_profile.push([RegName(CHFILT_I1			) + " " + chfilt_i1.value + "\n"	   ]);		
	reg_profile.push([RegName(CHFILT_I0			) + " " + chfilt_i0.value + "\n"	   ]);		
	reg_profile.push([RegName(CHFILT_Q2			) + " " + chfilt_q2.value + "\n"	   ]);		
	reg_profile.push([RegName(CHFILT_Q1			) + " " + chfilt_q1.value + "\n"	   ]);		
	reg_profile.push([RegName(CHFILT_Q0			) + " " + chfilt_q0.value + "\n"	   ]);		
	reg_profile.push([RegName(GPIO_STATUS		) + " " + gpio_status.value + "\n"	   ]);		
	reg_profile.push([RegName(FSCAL_CTRL		) + " " + fscal_ctrl.value + "\n"	   ]);		
	reg_profile.push([RegName(PHASE_ADJUST		) + " " + phase_adjust.value + "\n"	   ]);		
	reg_profile.push([RegName(PARTNUMBER		) + " " + partnumber.value + "\n"	   ]);		
	reg_profile.push([RegName(PARTVERSION		) + " " + partversion.value + "\n"	   ]);		
	reg_profile.push([RegName(SERIAL_STATUS		) + " " + serial_status.value + "\n"   ]);	
	reg_profile.push([RegName(MODEM_STATUS1		) + " " + modem_status1.value + "\n"   ]);	
	reg_profile.push([RegName(MODEM_STATUS0		) + " " + modem_status0.value + "\n"   ]);	
	reg_profile.push([RegName(MARC_STATUS1		) + " " + marc_status1.value + "\n"	   ]);		
	reg_profile.push([RegName(MARC_STATUS0		) + " " + marc_status0.value + "\n"	   ]);		
	reg_profile.push([RegName(PA_IFAMP_TEST		) + " " + pa_ifamp_test.value + "\n"   ]);	
	reg_profile.push([RegName(FSRF_TEST			) + " " + fsrf_test.value + "\n"	   ]);		
	reg_profile.push([RegName(PRE_TEST			) + " " + pre_test.value + "\n"		   ]);			
	reg_profile.push([RegName(PRE_OVR			) + " " + pre_ovr.value + "\n"		   ]);			
	reg_profile.push([RegName(ADC_TEST			) + " " + adc_test.value + "\n"		   ]);			
	reg_profile.push([RegName(DVC_TEST			) + " " + dvc_test.value + "\n"		   ]);			
	reg_profile.push([RegName(ATEST				) + " " + atest.value + "\n"		   ]);			
	reg_profile.push([RegName(ATEST_LVDS		) + " " + atest_lvds.value + "\n"	   ]);		
	reg_profile.push([RegName(ATEST_MODE		) + " " + atest_mode.value + "\n"	   ]);		
	reg_profile.push([RegName(XOSC_TEST1		) + " " + xosc_test1.value + "\n"	   ]);		
	reg_profile.push([RegName(XOSC_TEST0		) + " " + xosc_test0.value + "\n"	   ]);		
	reg_profile.push([RegName(AES				) + " " + aes.value + "\n"			   ]);				
	reg_profile.push([RegName(MDM_TEST			) + " " + mdm_test.value + "\n"		   ]);			
	reg_profile.push([RegName(RXFIRST			) + " " + rxfirst.value + "\n"		   ]);			
	reg_profile.push([RegName(TXFIRST			) + " " + txfirst.value + "\n"		   ]);			
	reg_profile.push([RegName(RXLAST			) + " " + rxlast.value + "\n"		   ]);			
	reg_profile.push([RegName(TXLAST			) + " " + txlast.value + "\n"		   ]);			
	reg_profile.push([RegName(NUM_TXBYTES		) + " " + num_txbytes.value + "\n"	   ]);		
	reg_profile.push([RegName(NUM_RXBYTES		) + " " + num_rxbytes.value + "\n"	   ]);		
	reg_profile.push([RegName(FIFO_NUM_TXBYTES	) + " " + fifo_num_txbytes.value + "\n"]);
	reg_profile.push([RegName(FIFO_NUM_RXBYTES	) + " " + fifo_num_rxbytes.value + "\n"]);
	reg_profile.push([RegName(RXFIFO_PRE_BUF	) + " " + rxfifo_pre_buf.value + "\n"  ]);	

	/* create a blob */
    var textToSaveAsBlob = new Blob(reg_profile, {type:"text/plain"});
    
    /* create an URL for the blob */
    var textToSaveAsURL = window.URL.createObjectURL(textToSaveAsBlob);
    
    //var fileNameToSaveAs = filename;
    
    /* create a download link */
    var downloadLink = document.createElement("a");
    downloadLink.download = filename;
    downloadLink.innerHTML = "Download File";
    downloadLink.href = textToSaveAsURL;
    downloadLink.style.display = "none";
    
    /* if the link is clicked, call function destroyClickedElement */
    downloadLink.onclick = destroyClickedElement;

    
    /* append the download link to the current document */
    document.body.appendChild(downloadLink);
 
 	/* emulate the click */
    downloadLink.click();
}



