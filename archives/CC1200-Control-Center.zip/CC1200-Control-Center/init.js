//* web-socket to BeagleBone Black                                                       */
var socket = io();

/* Debug flag                                                                           */
var Debug = false;

/* send an alive message                                                                */
//socket.emit('clientEvent', 'Sent first event from the client!');

/* if exporting a C file, this flag indicates, if the C file will contain a main routine*/
var IncludeMain = false;
var RegToRead = -1;
var CC1200State = 0;

var RSSI_ON = false;
var RSSI_time;
var SynTx_ON = false;

function Disable_HF_Params () {
	$( "#Carrier_Frequency" ).prop( "disabled", true );
}

function Enable_HF_Params () {
	$( "#Carrier_Frequency" ).prop( "disabled", false );
}


function RSSI_Switch() {
        
    if (RSSI_ON == false) {
        RSSI_ON = true;
        RSSI_time = 0.0;
        Disable_HF_Params();
	$("#rssi_button").html('RSSI off');
    } else {
        RSSI_ON = false;
    	$("#rssi_button").html('RSSI on');
		$("#RSSI_val").html('N. A.');
		CC1200_COMMAND (S_IDLE);
		Enable_HF_Params ();
    }
}

function SynTx_Switch() {

    if (SynTx_ON == false) {
        SynTx_ON = true;
        Disable_HF_Params();
        CC1200_COMMAND (S_TX);
		$("#SynTx_button").html('Stop Transmission');
    } else {
        SynTx_ON = false;
    	$("#SynTx_button").html('Start Transmission');
		CC1200_COMMAND (S_IDLE);
		Enable_HF_Params ();
    }
}

var Update_Param = true;
var Xtal_Frequency=40000000; 

function Print_XOSC () {

    $("#Xtal_Frequency").html(Xtal_Frequency/1000000 + ' Mhz');
}

function PrintCarrierFrequency () {

    var FREQ0_val = parseInt($("#FREQ0").val(), 16);
    var FREQ1_val = parseInt($("#FREQ1").val(), 16);
    var FREQ2_val = parseInt($("#FREQ2").val(), 16);

    var f_vco = (Xtal_Frequency/Math.pow(2, 16)) * ((FREQ2_val*0xFFFF)+(FREQ1_val*0xFF)+FREQ0_val);
    var freq  = (f_vco / 4)/1E6;

    $("#Carrier_Frequency").val(freq.toFixed(1));
}


function StopParamUpd () {
    
    Update_Param = false;
}

function ChangeFreq () {
    
    Update_Param = false;
    var new_freq = parseFloat($("#Carrier_Frequency").val());
    
    var FREQX = (new_freq*1E6*4/Xtal_Frequency)*Math.pow(2, 16);
    var FREQ0_val = parseInt(FREQX,10)&0xff;
    var FREQ1_val = (parseInt(FREQX,10)&0xFF00)>>8;
    var FREQ2_val = (parseInt(FREQX,10)&0xFF0000)>>16;
        
    WriteReg (FREQ2, FREQ2_val);
    WriteReg (FREQ1, FREQ1_val);
    WriteReg (FREQ0, FREQ0_val);
    
    ReadReg (FREQ2);
    ReadReg (FREQ1);
    ReadReg (FREQ0);
    Update_Param = true;



}


const FIXED_PKT_LEN      = 0;
const VARIABLE_PKT_LEN   = 1;
const INFINITE_PKT_LEN   = 2;
const VARIABLE_5_PKT_LEN = 3;

function SetPacketMode () {

    var pkt_len_mode = $( "#Length_Config option:selected" ).val();
    
    var mode;

    ReadReg(PKT_CFG0);
    setTimeout(() => { console.log("World!"); }, 500);
    
    mode = ((parseInt($("#PKT_CFG0").val(), 16))&0x9F) + (pkt_len_mode<<5);
    WriteReg(PKT_CFG0, mode);
    ReadReg(PKT_CFG0);
 
}

function GetPacketMode () {

    var pkt_len_mode = ((parseInt($("#PKT_CFG0").val(), 16))&0x60)>>5;
    
    switch (pkt_len_mode){
        case FIXED_PKT_LEN:
            $("#PKT_CFG0").val('Fixed');
            break;
        case VARIABLE_PKT_LEN:
            $("#PKT_CFG0").val('Variable');
            break;
        default:
            console.log ("Unknown packet mode:" + pkt_len_mode);
    }
}

var Start_Rx = false;

function Packet_Rx() {

    var pkt_len_mode = $( "#Length_Config option:selected" ).val();;

    if (Start_Rx == false) {
        Start_Rx = true;
  		$("#RX_Packet_Output").html("");
  		
        Disable_HF_Params();
        SetPacketMode();
        $("#FIFO_RX_button").html('Stop');
        CC1200_COMMAND(S_FRX);
        StartRx();
    } else {
        Start_Rx = false;
        StopRx();
        $("#FIFO_RX_button").html('Start');
        Enable_HF_Params ();
    }
}

var Start_Tx = false;

function Packet_Tx() {

    var pkt_len_mode = $( "#Length_Config option:selected" ).val();;

    if (Start_Tx == false) {
        Start_Tx = true;
  		//$("#RX_Packet_Output").html("");
  		
        Disable_HF_Params();
        //SetPacketMode();
        $("#FIFO_TX_button").html('Stop');
        StartTx();
    } else {
        Start_Tx = false;
        StopTx();
        $("#FIFO_TX_button").html('Start');
        Enable_HF_Params ();
    }
}

function Length_Config() {

    var conceptName = $('#Length_Config').find(":selected").text();

    if (conceptName.localeCompare("Fixed")==0) {
        $("#Frame_Length").val(5);

        $("#Frame_Length").attr('class', 'frame_show');
        $("#frame_length").attr('class', 'frame_show');
        $("#frame_end").attr('class', 'frame_show');
        console.log ("is fixed");
    }
    if (conceptName.localeCompare("Variable")==0) {
        console.log ("Variable");
        $("#Frame_Length").attr('class', 'frame_hidden');
        $("#frame_length").attr('class', 'frame_hidden');
        $("#frame_end").attr('class', 'frame_hidden');
    }

}
var seq_on;
function Add_Sequence() {
		var add_seq = ($('#Add_Seq').is(':checked'));
		
		if (add_seq)
			seq_on = 1;
		else
			seq_on = 0;
}

function TX_Add_Sequence() {
		var add_seq = ($('#TX_Add_Seq').is(':checked'));
		var len = $("#TX_Frame_Length").val();
		
		if (add_seq)
			$("#TX_Frame_Length").val(parseInt(len)+2);
		else
			$("#TX_Frame_Length").val(parseInt(len)-2);
}

var tx_frame;

function GetTxFrame() {

    var key = window.event.keyCode;
    var len;
    
    $('#TX_Packet_Input').keyup( function() {
        $(this).val( $(this).val().replace( /\r?\n/gi, '' ) );
        });
    $('#TX_Packet_Input').keyup( function() {
        $(this).val( $(this).val().replace( /\r?\n/gi, '' ) );
        });

    tx_frame = $("#TX_Packet_Input").val();
    len   
 
    if (key == 13) 
        len = tx_frame.length-1;
    else
        len = tx_frame.length;
        
    if (($('#TX_Add_Seq').is(':checked'))) len+=2;
     
    $("#TX_Frame_Length").val(len);
    console.log ("Frame:" + tx_frame + " length: " + len);

}

var Max_Pkt_Cnt=$("#Packet_Count").val();
var Pkt_Cnt=0;

function UpdateCC1200State () {
	CC1200RetrieveState();
	if (RSSI_ON) {
		RSSIGet();
		GetRssiOffset();
	}
	Print_XOSC();
	if (Update_Param==true) PrintCarrierFrequency();
}

var chart;

var dData = function() {
  return Math.round(Math.random() * 90) + 10;
};

var time_index = 0;
var rssi_index = 0;

function AddRSSI (time, value) {

	if (rssi_index<=30) {
		chart.data.datasets[0].data[rssi_index] = value;
		chart.data.labels[rssi_index] = time;
		rssi_index++;
	} else {
		for (idx=0; idx<30; idx++) {
			chart.data.datasets[0].data[idx] = chart.data.datasets[0].data[idx+1];
			chart.data.labels[idx] = chart.data.labels[idx+1];
		}
		chart.data.datasets[0].data[30] = value;
		chart.data.labels[30] = time;
	}
	
	$("#RSSI_val").html(value);
	
}

function Mychart () {
	var ctx = document.getElementById('myChart').getContext('2d');

	chart = new Chart(ctx, {
    // The type of chart we want to create
    type: 'line',

    // The data for our dataset
    data: {
    /*
        labels: ["January", "February", "March", "April", "May", "June", "July",
        		 "January", "February", "March", "April", "May", "June", "July"],
    */
    /*    labels: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10],*/
        labels: [],
        datasets: [{
            label: "RSSI",
            backgroundColor: 'rgb(255, 99, 132)',
            pointStyle: 'line',
            showLines: false,
            fill: false,
            borderColor: 'rgb(255, 99, 132)',
            /*
            data: [-127, 10, 5, 2, 20, 30, 45,
            	   0, 10, 5, 2, 20, 30, 45],
            */
            data: [],
        }]
    },

    // Configuration options go here
    options: {
    	title: {
    		display: true,
            text: 'Received Signal Strength Indicator (RSSI)'
    	},
    	legend: {
            display: false
        },
    	tooltips: {
            enabled: false
        },
    	scales: {
    		yAxes: [{
    			scaleLabel: {
    				display: true,
    				labelString: 'dBm'
    			}
    		}],
    		xAxes: [{
    			scaleLabel: {
    				display: true,
    				labelString: 'time [s]'
    			}
    		}]
    	},
    	maintainAspectRatio: false,
    	responsive: true
    	}
	});
}
	
function init () {
	Parse_Reg_File();
	window.setInterval (UpdateCC1200State, 1000);
	Mychart ();
}

window.onload = init;


const IDLE          = 0;
const RX            = 1;
const TX            = 2;
const FSTXON        = 3;
const CALLIBRATE    = 4;
const SETTLING      = 5;
const RX_FIFO_ERROR = 6;
const TX_FIFO_ERROR = 7;

function print_status () {

        switch (CC1200State) {
        case 0: return "IDLE          "; break;
        case 1: return "RX            "; break;
        case 2: return "TX            "; break;
        case 3: return "FSTXON        "; break;
        case 4: return "CALLIBRATE    "; break;
        case 5: return "SETTLING      "; break;
        case 6: return "RX_FIFO_ERROR "; break;
        case 7: return "TX_FIFO_ERROR "; break;
        default : return "UNKNOWN     "; break;
        }
}

