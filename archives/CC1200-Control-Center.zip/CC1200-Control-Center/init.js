//* web-socket to BeagleBone Black                                                       */
var socket = io();

/* Debug flag                                                                           */
var Debug = false;

/* send an alive message                                                                */
//socket.emit('clientEvent', 'Sent first event from the client!');

/* if exporting a C file, this flag indicates, if the C file will contain a main routine*/
var IncludeMain = false;
var RegToRead = -1;
var CC1200State = 0;

var RSSI_ON = false;
var RSSI_time;
var SynTx_ON = false;

function Disable_HF_Params () {
	$( "#Carrier_Frequency" ).prop( "disabled", true );
}

function Enable_HF_Params () {
	$( "#Carrier_Frequency" ).prop( "disabled", false );
}


function RSSI_Switch() {
        
    if (RSSI_ON == false) {
        RSSI_ON = true;
        RSSI_time = 0.0;
        Disable_HF_Params();
	$("#rssi_button").html('RSSI off');
    } else {
        RSSI_ON = false;
    	$("#rssi_button").html('RSSI on');
		$("#RSSI_val").html('N. A.');
		CC1200_COMMAND (S_IDLE);
		Enable_HF_Params ();
    }
}

function SynTx_Switch() {

    if (SynTx_ON == false) {
        SynTx_ON = true;
        Disable_HF_Params();
        CC1200_COMMAND (S_TX);
		$("#SynTx_button").html('Stop Transmission');
    } else {
        SynTx_ON = false;
    	$("#SynTx_button").html('Start Transmission');
		CC1200_COMMAND (S_IDLE);
		Enable_HF_Params ();
    }
}

var Update_Param = true;
var Xtal_Frequency=40000000; 

function Print_XOSC () {

    $("#Xtal_Frequency").html(Xtal_Frequency/1000000 + ' Mhz');
}

function PrintSymbolRate () {

    var SYMBOL_RATE2_val = parseInt($("#SYMBOL_RATE2").val(), 16);
    var SYMBOL_RATE1_val = parseInt($("#SYMBOL_RATE1").val(), 16);
    var SYMBOL_RATE0_val = parseInt($("#SYMBOL_RATE0").val(), 16);

    var symbol_rate = 0.0;    
    var SRATE_E = (SYMBOL_RATE2_val&0xF0)>>4;
    var SRATE_M = ((SYMBOL_RATE2_val&0x0F)*0xFFFF)+(SYMBOL_RATE1_val*0xFF)+SYMBOL_RATE0_val;
    
    if (SRATE_E>0) {
        symbol_rate = (Xtal_Frequency/Math.pow(2, 39))*(Math.pow(2, 20)+SRATE_M)*Math.pow(2, SRATE_E);
    } else {
        symbol_rate = (Xtal_Frequency/Math.pow(2, 38))*SRATE_M;
    }
    symbol_rate /= 1000.0;
    $("#Symbol_Rate").val(symbol_rate.toFixed(2));

}

function PrintCarrierFrequency () {

    var FREQ0_val = parseInt($("#FREQ0").val(), 16);
    var FREQ1_val = parseInt($("#FREQ1").val(), 16);
    var FREQ2_val = parseInt($("#FREQ2").val(), 16);

    var f_vco = (Xtal_Frequency/Math.pow(2, 16)) * ((FREQ2_val*0xFFFF)+(FREQ1_val*0xFF)+FREQ0_val);
    var freq  = (f_vco / 4)/1E6;

    $("#Carrier_Frequency").val(freq.toFixed(1));
}


function StopParamUpd () {
    
    Update_Param = false;
}

function ChangeFreq () {
    
    Update_Param = false;
    var new_freq = parseFloat($("#Carrier_Frequency").val());
    
    var FREQX = (new_freq*1E6*4/Xtal_Frequency)*Math.pow(2, 16);
    var FREQ0_val = parseInt(FREQX,10)&0xff;
    var FREQ1_val = (parseInt(FREQX,10)&0xFF00)>>8;
    var FREQ2_val = (parseInt(FREQX,10)&0xFF0000)>>16;
        
    WriteReg (FREQ2, FREQ2_val);
    WriteReg (FREQ1, FREQ1_val);
    WriteReg (FREQ0, FREQ0_val);
    
    ReadReg (FREQ2);
    ReadReg (FREQ1);
    ReadReg (FREQ0);
    Update_Param = true;
}

function ChangeSymbolRate () {
    Update_Param = false;
    var new_symbol_rate = 1000.0 * parseFloat($("#Symbol_Rate").val());
    if (new_symbol_rate>500000.0) {
        alert ("Symbol rate is too high and should not exceed 500ksps");
        new_symbol_rate=500000.0;
    }
    
    var SRATE_E = Math.trunc(Math.log2((Math.pow(2, 39)/Xtal_Frequency)*new_symbol_rate)-20);
    var SRATE_S = ((Math.pow(2, 39)/Xtal_Frequency)*new_symbol_rate/Math.pow(2, SRATE_E))-Math.pow(2, 20);
            
    WriteReg (SYMBOL_RATE2, ((parseInt(SRATE_S,10)&0xFF0000)>>16)+(parseInt(SRATE_E,10)<<4));
    WriteReg (SYMBOL_RATE1, (parseInt(SRATE_S,10)&0xFF00)>>8);
    WriteReg (SYMBOL_RATE0, parseInt(SRATE_S,10)&0xff);
    
    ReadReg (SYMBOL_RATE2);
    ReadReg (SYMBOL_RATE1);
    ReadReg (SYMBOL_RATE0);
    Update_Param = true;
}

function PrintDeviation () {

    var DEVIATION_M_val = parseInt($("#DEVIATION_M").val(),16);
    var DEVIATION_E_val = parseInt($("#MODCFG_DEV_E").val(),16)&0x07;
    var deviation;
    
    if (DEVIATION_E_val==0)
        deviation = (Xtal_Frequency/Math.pow(2, 21))*DEVIATION_M_val
    else
        deviation = (Xtal_Frequency/Math.pow(2, 22))*(256.0 + DEVIATION_M_val) * Math.pow(2, DEVIATION_E_val)/1000.0;
        
    $("#Deviation").val(deviation.toFixed(6));
    
    var modulation_index = deviation / parseFloat($("#Symbol_Rate").val());
    $("#Modulation_Index").html(modulation_index.toFixed(6));
}

function ChangeDeviation () {
    Update_Param = false;

    var f_dev = 1000*parseFloat($("#Deviation").val());
    if (f_dev>623779.297) {
        f_dev=623779.0
        alert('Devation exceeds maximim !!!');
    }

    var DEV_M = 1;
    var DEV_E = 0;
    var last_DEV_M;
        
    while (DEV_M>0) {
        DEV_M = Math.round((Math.pow(2, 22)/Xtal_Frequency) * (f_dev/Math.pow(2, DEV_E)) - 256);
        if (DEV_M>0) {
            last_DEV_M = DEV_M;
            DEV_E++;
       } 
    }
 
    if (DEV_M<0 && DEV_E<=8) {
        DEV_M=last_DEV_M;
        DEV_E--;
   } else {
       DEV_M = (Math.pow(2, 21)/Xtal_Frequency)*f_dev/1000.0;
       DEV_E = 0;
    }
    
    DEV_M = Math.round(DEV_M);
    DEV_M= parseInt(DEV_M,10);
    
    WriteReg (DEVIATION_M, DEV_M);
    WriteReg (MODCFG_DEV_E, (parseInt($("#MODCFG_DEV_E").val(),16)&0xF8)+DEV_E);
 
    ReadReg (DEVIATION_M);
    ReadReg (MODCFG_DEV_E);
    
    setTimeout(() => { 
        PrintDeviation();    
        console.log ("DEV_M:" + DEV_M + " DEV_E:" + DEV_E + " Deviation:" + $("#Deviation").val());
        }, 500);
        
    Update_Param = true;    
}

const MODULATION_2_FSK      = 0;
const MODULATION_2_GFSK     = 1;
const MODULATION_ASK        = 3;
const MODULATION_4_FSK      = 4;
const MODULATION_4_GFSK     = 5;

function PrintModulation () {

    var modulation_format_val = (parseInt($("#MODCFG_DEV_E").val(),16)&0x38)>>3;
    $("#Modulation_Format").val(modulation_format_val);
}

function ChangeModulation () {

    Update_Param = false;
    var modulation_val = parseInt($("#Modulation_Format").val(),10);
    var modulation_format_val = parseInt($("#MODCFG_DEV_E").val(),16);
    
    WriteReg (MODCFG_DEV_E,(modulation_format_val&0xC7)+(modulation_val<<3));
    ReadReg (MODCFG_DEV_E);

    setTimeout(() => {PrintModulation();}, 500);
    Update_Param = true;    
}

function PrintBitRate () {
    var modulation = (parseInt($("#MODCFG_DEV_E").val(),16)&0x38)>>3;
    var symbol_rate = parseFloat($("#Symbol_Rate").val());
    var mutiplier = 0;
    
    switch (modulation) {
        case MODULATION_2_FSK : 
        case MODULATION_2_GFSK:
        case MODULATION_ASK   : mutiplier=1; break;
        case MODULATION_4_FSK : 
        case MODULATION_4_GFSK: mutiplier=2; break;
    }
    
    $("#Bit_Rate").html(symbol_rate*mutiplier + ' khz');

}

const FIXED_PKT_LEN      = 0;
const VARIABLE_PKT_LEN   = 1;
const INFINITE_PKT_LEN   = 2;
const VARIABLE_5_PKT_LEN = 3;

function SetPacketMode () {

    var pkt_len_mode = $( "#Length_Config option:selected" ).val();
    
    var mode;

    ReadReg(PKT_CFG0);
    setTimeout(() => { console.log("World!"); }, 500);
    
    mode = ((parseInt($("#PKT_CFG0").val(), 16))&0x9F) + (pkt_len_mode<<5);
    WriteReg(PKT_CFG0, mode);
    ReadReg(PKT_CFG0);
 
}

function SetTxPacketMode () {

    var pkt_len_mode = $( "#TX_Length_Config option:selected" ).val();
    
    var mode;

    ReadReg(PKT_CFG0);
    setTimeout(() => { console.log("World!"); }, 500);
    
    mode = ((parseInt($("#PKT_CFG0").val(), 16))&0x9F) + (pkt_len_mode<<5);
    WriteReg(PKT_CFG0, mode);
    ReadReg(PKT_CFG0);
 
}

function GetPacketMode () {

    var pkt_len_mode = ((parseInt($("#PKT_CFG0").val(), 16))&0x60)>>5;
    
    switch (pkt_len_mode){
        case FIXED_PKT_LEN:
            $("#PKT_CFG0").val('Fixed');
            break;
        case VARIABLE_PKT_LEN:
            $("#PKT_CFG0").val('Variable');
            break;
        default:
            console.log ("Unknown packet mode:" + pkt_len_mode);
    }
}

var Start_Rx = false;

function Packet_Rx() {

    var pkt_len_mode = $( "#Length_Config option:selected" ).val();;

    if (Start_Rx == false) {
        Start_Rx = true;
  		$("#RX_Packet_Output").html("");
  		
        Disable_HF_Params();
        SetPacketMode();
        $("#FIFO_RX_button").html('Stop');
        CC1200_COMMAND(S_FRX);
        StartRx();
    } else {
        Start_Rx = false;
        StopRx();
        $("#FIFO_RX_button").html('Start');
        Enable_HF_Params ();
    }
}

var Start_Tx = false;

function Packet_Tx() {

    var pkt_len_mode = $( "#Length_Config option:selected" ).val();;

    if (Start_Tx == false) {
        Start_Tx = true;
  		//$("#RX_Packet_Output").html("");
  		
        Disable_HF_Params();
        //SetPacketMode();
        $("#FIFO_TX_button").html('Stop');
        StartTx();
    } else {
        Start_Tx = false;
        StopTx();
        $("#FIFO_TX_button").html('Start');
        Enable_HF_Params ();
    }
}

function Frame_Length() {
	var lenght = $("#Frame_Length").val();
	
	    WriteReg(PKT_LEN, parseInt(lenght, 10));
    	ReadReg(PKT_LEN);
}

function TX_Frame_Length() {
	var lenght = $("#TX_Frame_Length").val();
	
	    WriteReg(PKT_LEN, parseInt(lenght, 10));
    	ReadReg(PKT_LEN);
}

function TX_Length_Config() {

    var conceptName = $('#TX_Length_Config').find(":selected").text();
    
    SetTxPacketMode();
    GetPacketMode();

    if (conceptName.localeCompare("Fixed")==0) {
        TX_Frame_Length();
        console.log ("is fixed");
    }
    if (conceptName.localeCompare("Variable")==0) {
        console.log ("Variable");
    	WriteReg(PKT_LEN, 0xFF);
    	ReadReg(PKT_LEN);
    }

}

function Length_Config() {

    var conceptName = $('#Length_Config').find(":selected").text();
    
     SetPacketMode();
     GetPacketMode();


    if (conceptName.localeCompare("Fixed")==0) {
        $("#Frame_Length").val(5);

        $("#Frame_Length").attr('class', 'frame_show');
        $("#frame_length").attr('class', 'frame_show');
        $("#frame_end").attr('class', 'frame_show');
        Frame_Length();
        console.log ("is fixed");
    }
    if (conceptName.localeCompare("Variable")==0) {
        console.log ("Variable");
        $("#Frame_Length").attr('class', 'frame_hidden');
        $("#frame_length").attr('class', 'frame_hidden');
        $("#frame_end").attr('class', 'frame_hidden');
    	WriteReg(PKT_LEN, 0xFF);
    	ReadReg(PKT_LEN);
    }

}
var seq_on;
function Add_Sequence() {
		var add_seq = ($('#Add_Seq').is(':checked'));
		
		if (add_seq)
			seq_on = 1;
		else
			seq_on = 0;
}

function TX_Add_Sequence() {
		var add_seq = ($('#TX_Add_Seq').is(':checked'));
		var len = $("#TX_Frame_Length").val();
		
		if (add_seq)
			$("#TX_Frame_Length").val(parseInt(len)+2);
		else
			$("#TX_Frame_Length").val(parseInt(len)-2);
}

var tx_frame;

function GetTxFrame() {

    var key = window.event.keyCode;
    var len;
    
    $('#TX_Packet_Input').keyup( function() {
        $(this).val( $(this).val().replace( /\r?\n/gi, '' ) );
        });
    $('#TX_Packet_Input').keyup( function() {
        $(this).val( $(this).val().replace( /\r?\n/gi, '' ) );
        });

    tx_frame = $("#TX_Packet_Input").val();
    len   
 
    if (key == 13) 
        len = tx_frame.length-1;
    else
        len = tx_frame.length;
        
    if (($('#TX_Add_Seq').is(':checked'))) len+=2;
     
    $("#TX_Frame_Length").val(len);
    console.log ("Frame:" + tx_frame + " length: " + len);
    TX_Frame_Length();

}

var Max_Pkt_Cnt=$("#Packet_Count").val();
var Pkt_Cnt=0;

function UpdateCC1200State () {
	CC1200RetrieveState();
	if (RSSI_ON) {
		RSSIGet();
		GetRssiOffset();
	}
	Print_XOSC();
	PrintBitRate();
	if (Update_Param==true) {
	    PrintCarrierFrequency();
	    PrintSymbolRate();
	    PrintDeviation();
    	PrintModulation();
	}
}

var chart;

var dData = function() {
  return Math.round(Math.random() * 90) + 10;
};

var time_index = 0;
var rssi_index = 0;

function AddRSSI (time, value) {

	if (rssi_index<=30) {
		chart.data.datasets[0].data[rssi_index] = value;
		chart.data.labels[rssi_index] = time;
		rssi_index++;
	} else {
		for (idx=0; idx<30; idx++) {
			chart.data.datasets[0].data[idx] = chart.data.datasets[0].data[idx+1];
			chart.data.labels[idx] = chart.data.labels[idx+1];
		}
		chart.data.datasets[0].data[30] = value;
		chart.data.labels[30] = time;
	}
	
	$("#RSSI_val").html(value);
	
}

function Mychart () {
	var ctx = document.getElementById('myChart').getContext('2d');

	chart = new Chart(ctx, {
    // The type of chart we want to create
    type: 'line',

    // The data for our dataset
    data: {
    /*
        labels: ["January", "February", "March", "April", "May", "June", "July",
        		 "January", "February", "March", "April", "May", "June", "July"],
    */
    /*    labels: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10],*/
        labels: [],
        datasets: [{
            label: "RSSI",
            backgroundColor: 'rgb(255, 99, 132)',
            pointStyle: 'line',
            showLines: false,
            fill: false,
            borderColor: 'rgb(255, 99, 132)',
            /*
            data: [-127, 10, 5, 2, 20, 30, 45,
            	   0, 10, 5, 2, 20, 30, 45],
            */
            data: [],
        }]
    },

    // Configuration options go here
    options: {
    	title: {
    		display: true,
            text: 'Received Signal Strength Indicator (RSSI)'
    	},
    	legend: {
            display: false
        },
    	tooltips: {
            enabled: false
        },
    	scales: {
    		yAxes: [{
    			scaleLabel: {
    				display: true,
    				labelString: 'dBm'
    			}
    		}],
    		xAxes: [{
    			scaleLabel: {
    				display: true,
    				labelString: 'time [s]'
    			}
    		}]
    	},
    	maintainAspectRatio: false,
    	responsive: true
    	}
	});
}
	
function init () {
	Parse_Reg_File();
	window.setInterval (UpdateCC1200State, 1000);
	Mychart ();
}

window.onload = init;


const IDLE          = 0;
const RX            = 1;
const TX            = 2;
const FSTXON        = 3;
const CALLIBRATE    = 4;
const SETTLING      = 5;
const RX_FIFO_ERROR = 6;
const TX_FIFO_ERROR = 7;

function print_status () {

        switch (CC1200State) {
        case 0: return "IDLE          "; break;
        case 1: return "RX            "; break;
        case 2: return "TX            "; break;
        case 3: return "FSTXON        "; break;
        case 4: return "CALLIBRATE    "; break;
        case 5: return "SETTLING      "; break;
        case 6: return "RX_FIFO_ERROR "; break;
        case 7: return "TX_FIFO_ERROR "; break;
        default : return "UNKNOWN     "; break;
        }
}

